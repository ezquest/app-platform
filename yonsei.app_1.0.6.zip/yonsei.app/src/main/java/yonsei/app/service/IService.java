package yonsei.app.service;

import io.vertx.core.json.JsonObject;

public interface IService {
    JsonObject execute(String method, JsonObject jsonBody);
}
