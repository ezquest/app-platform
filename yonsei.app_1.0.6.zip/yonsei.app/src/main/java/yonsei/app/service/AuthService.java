package yonsei.app.service;

import io.vertx.core.json.JsonObject;
import yonsei.app.command.*;

import java.util.HashMap;

public class AuthService implements IService {

    private static AuthService sInstance = new AuthService();

    private HashMap<String, ICommand> mJsonFuncMap = new HashMap<>();


    private AuthService() {
        mJsonFuncMap.put(AuthSignInCommand.commandName, new AuthSignInCommand());
        mJsonFuncMap.put(AuthSignUpCommand.commandName, new AuthSignUpCommand());
        mJsonFuncMap.put(AuthSignOutCommand.commandName, new AuthSignOutCommand());
        mJsonFuncMap.put(AuthSignDropCommand.commandName, new AuthSignDropCommand());
    }

    public static AuthService getInstance() {
        return sInstance;
    }

    @Override
    public JsonObject execute(String method, JsonObject jsonBody) {

        ICommand command = mJsonFuncMap.get(method);
        if (command != null) {
            return command.execute(jsonBody);
        } else {
            return ResponseMessage.BAD_REQUEST.toJson();
        }
    }
}
