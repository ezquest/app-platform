package yonsei.app.service;


import io.vertx.core.json.JsonObject;
import yonsei.app.command.ResponseMessage;

import java.util.HashMap;
import java.util.StringTokenizer;


public class CommandService {
    private static CommandService sInstance = new CommandService();

    private HashMap<String, IService> mServiceMap = new HashMap<>();

    public static CommandService getInstance() {
        return sInstance;
    }

    private CommandService() {
        mServiceMap.put("Auth", AuthService.getInstance());
        mServiceMap.put("User", UserService.getInstance());
    }

    public JsonObject execute(JsonObject jsonBody) {
        System.out.println("[Request body]");
        System.out.println(jsonBody);
        String method = jsonBody.getString("command", "None");
        StringTokenizer token = new StringTokenizer(method, ":");
        if (token.hasMoreTokens()) {
            IService service = mServiceMap.get(token.nextToken());
            if (service != null) {
                return service.execute(method, jsonBody);
            }
        }

        return ResponseMessage.BAD_REQUEST.toJson();
    }
}
