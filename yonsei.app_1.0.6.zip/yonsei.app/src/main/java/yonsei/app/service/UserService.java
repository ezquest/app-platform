package yonsei.app.service;

import io.vertx.core.json.JsonObject;
import yonsei.app.command.ICommand;
import yonsei.app.command.UserGetUserInfoCommand;
import yonsei.app.command.UserUpdateUserInfoCommand;
import yonsei.app.command.ResponseMessage;

import java.util.HashMap;

public class UserService implements IService {

    private static UserService sInstance = new UserService();

    private HashMap<String, ICommand> mJsonFuncMap = new HashMap<>();


    private UserService() {
        mJsonFuncMap.put(UserGetUserInfoCommand.commandName, new UserGetUserInfoCommand());
        mJsonFuncMap.put(UserUpdateUserInfoCommand.commandName, new UserUpdateUserInfoCommand());
    }

    public static UserService getInstance() {
        return sInstance;
    }

    @Override
    public JsonObject execute(String method, JsonObject jsonBody) {

        ICommand command = mJsonFuncMap.get(method);
        if (command != null) {
            return command.execute(jsonBody);
        } else {
            return ResponseMessage.BAD_REQUEST.toJson();
        }
    }
}
