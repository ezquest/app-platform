package yonsei.app.common;

public final class Config {
    public static final String REDIS_HOST = "127.0.0.1";
    public static final int REDIS_PORT = 7468;
    public static final String REDIS_PASSWORD = "asdf1234";
}
