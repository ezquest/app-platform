package yonsei.app.common;

public class ObjectUtils {

    public static boolean isNull(Object object) {
        return object == null;
    }
}
