package yonsei.app.command;

import io.vertx.core.json.JsonObject;

public interface ICommand {
    JsonObject execute(JsonObject jsonObject);
}
