package yonsei.app.command;

import io.vertx.core.json.JsonObject;
import yonsei.app.common.TextUtils;
import yonsei.app.repository.UserInfoRepository;
import yonsei.app.repository.UserRepository;

public class AuthSignUpCommand implements ICommand {
    public static final String commandName = "Auth:SignUp";

    @Override
    public JsonObject execute(JsonObject jsonObject) {
        if (jsonObject.containsKey("id") && jsonObject.containsKey("password")) {
            String id = jsonObject.getString("id", "");
            String password = jsonObject.getString("password", "");
            if (TextUtils.isEmpty(id) || TextUtils.isEmpty(password)) {
                return ResponseMessage.SIGN_UP_ERROR.toJson();
            }
            if (UserRepository.getInstance().isIdValid(id)) {
                return ResponseMessage.SIGN_UP_EXIST.toJson();
            }

            String uid = UserRepository.getInstance().addUser(id, password);
            if (TextUtils.isEmpty(uid)) {
                return ResponseMessage.INTERNAL_ERROR.toJson();
            }

            if (jsonObject.containsKey("profile")) {
                JsonObject profile = jsonObject.getJsonObject("profile");
                UserInfoRepository.getInstance().addProfile(uid, profile);
            }
            return ResponseMessage.SIGN_UP_SUCCESS.toJson();
        }
        return ResponseMessage.SIGN_UP_ERROR.toJson();
    }
}
