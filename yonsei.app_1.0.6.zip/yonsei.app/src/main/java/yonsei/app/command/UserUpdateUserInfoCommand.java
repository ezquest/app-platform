package yonsei.app.command;

import io.vertx.core.json.JsonObject;
import yonsei.app.common.TextUtils;
import yonsei.app.repository.SessionIdRepository;
import yonsei.app.repository.UserInfoRepository;

public class UserUpdateUserInfoCommand implements ICommand {
    public static final String commandName = "User:UpdateUserInfo";

    @Override
    public JsonObject execute(JsonObject jsonObject) {
        if (jsonObject.containsKey("sessionId")
                && jsonObject.containsKey("profile")) {
            String sessionId = jsonObject.getString("sessionId", "");
            if (TextUtils.isEmpty(sessionId)) {
                return ResponseMessage.UNAUTHORIZED.toJson();
            }

            String uid = SessionIdRepository.getInstance().getUid(sessionId);
            if (TextUtils.isEmpty(uid)) {
                return ResponseMessage.UNAUTHORIZED.toJson();
            }

            JsonObject profile = jsonObject.getJsonObject("profile");
            UserInfoRepository.getInstance().updateProfile(uid, profile);
            return ResponseMessage.SUCCESS.toJson();
        }
        return ResponseMessage.BAD_REQUEST.toJson();
    }
}
