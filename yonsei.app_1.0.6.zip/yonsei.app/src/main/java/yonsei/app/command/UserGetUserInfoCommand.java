package yonsei.app.command;

import io.vertx.core.json.JsonObject;
import yonsei.app.common.Pair;
import yonsei.app.common.TextUtils;
import yonsei.app.repository.SessionIdRepository;
import yonsei.app.repository.UserInfoRepository;


public class UserGetUserInfoCommand implements ICommand {
    public static final String commandName = "User:GetUserInfo";

    @Override
    public JsonObject execute(JsonObject jsonObject) {
        if (jsonObject.containsKey("sessionId")) {
            String sessionId = jsonObject.getString("sessionId", "");
            if (TextUtils.isEmpty(sessionId)) {
                return ResponseMessage.UNAUTHORIZED.toJson();
            }

            String uid = SessionIdRepository.getInstance().getUid(sessionId);
            if (TextUtils.isEmpty(uid)) {
                return ResponseMessage.UNAUTHORIZED.toJson();
            }
            JsonObject profile = UserInfoRepository.getInstance().getProfile(uid);
            return ResponseMessage.SUCCESS.setExtra(new Pair<>("profile", profile)).toJsonWithExtra();
        }
        return ResponseMessage.BAD_REQUEST.toJson();
    }
}
