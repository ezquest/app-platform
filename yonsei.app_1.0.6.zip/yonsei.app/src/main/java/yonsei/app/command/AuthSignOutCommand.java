package yonsei.app.command;

import io.vertx.core.json.JsonObject;
import yonsei.app.common.TextUtils;
import yonsei.app.repository.SessionIdRepository;

public class AuthSignOutCommand implements ICommand {
    public static final String commandName = "Auth:SignOut";

    @Override
    public JsonObject execute(JsonObject jsonObject) {
        if (jsonObject.containsKey("sessionId")) {
            String sessionId = jsonObject.getString("sessionId", "");
            if (TextUtils.isEmpty(sessionId)) {
                return ResponseMessage.UNAUTHORIZED.toJson();
            }
            String uid = SessionIdRepository.getInstance().getUid(sessionId);
            if (TextUtils.isEmpty(uid)) {
                return ResponseMessage.UNAUTHORIZED.toJson();
            }
            SessionIdRepository.getInstance().deleteSessionBySessionId(sessionId);
            return ResponseMessage.SUCCESS.toJson();
        }
        return ResponseMessage.UNAUTHORIZED.toJson();
    }
}
