package yonsei.app.command;

import io.vertx.core.json.JsonObject;
import yonsei.app.common.ObjectUtils;
import yonsei.app.common.Pair;
import yonsei.app.common.TextUtils;
import yonsei.app.repository.SessionIdRepository;
import yonsei.app.repository.UserRepository;

import javax.xml.soap.Text;
import java.util.UUID;

import static yonsei.app.command.ResponseMessage.*;

public class AuthSignInCommand implements ICommand {
    public static final String commandName = "Auth:SignIn";

    @Override
    public JsonObject execute(JsonObject jsonObject) {
        if (jsonObject.containsKey("id") && jsonObject.containsKey("password")) {
            String id = jsonObject.getString("id", "");
            String password = jsonObject.getString("password", "");

            if (TextUtils.isEmpty(id) || TextUtils.isEmpty(password)) {
                return ResponseMessage.SIGN_IN_FAILED.toJson();
            }

            JsonObject user = UserRepository.getInstance().getUserById(id);
            if (ObjectUtils.isNull(user)) {
                return ResponseMessage.SIGN_IN_FAILED.toJson();
            }

            String userPassword = user.getString("password");
            if (!TextUtils.equals(password, userPassword)) {
                return ResponseMessage.SIGN_IN_FAILED.toJson();
            }

            String userUid = UserRepository.getInstance().findUidById(id);
            if (TextUtils.isEmpty(userUid)) {
                return ResponseMessage.INTERNAL_ERROR.toJson();
            }
            SessionIdRepository.getInstance().deleteSession(userUid);
            String sessionId = SessionIdRepository.getInstance().addSession(userUid);
            if (TextUtils.isEmpty(sessionId)) {
                return ResponseMessage.INTERNAL_ERROR.toJson();
            }
            return SIGN_IN_SUCCESS.setExtra(new Pair<>("sessionId", sessionId)).toJsonWithExtra();
        }
        return ResponseMessage.SIGN_IN_FAILED.toJson();
    }
}
