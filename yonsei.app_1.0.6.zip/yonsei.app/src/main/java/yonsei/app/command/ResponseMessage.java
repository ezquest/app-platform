package yonsei.app.command;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.vertx.core.json.JsonObject;
import yonsei.app.common.Pair;

import java.io.IOException;

//@JsonFormat(shape = JsonFormat.Shape.OBJECT)
//@JsonInclude(JsonInclude.Include.NON_NULL)

@JsonSerialize(using = ResponseMessage.ResponseMessageSerializer.class)
public enum ResponseMessage {

    SUCCESS(200, "The request is successful"),
    BAD_REQUEST(400, "Bad request"),
    UNAUTHORIZED(403, "Unauthorized"),
    INTERNAL_ERROR(500, "Interval server error"),

    SIGN_UP_SUCCESS(200, "Account successfully created."),
    SIGN_UP_ERROR(400, "Invalid user ID and Password."),
    SIGN_UP_EXIST(409, "Account already exists."),

    SIGN_IN_SUCCESS(200, "You have successfully signed in."),
    SIGN_IN_FAILED(401, "Incorrect user ID or Password.");

    //    @JsonProperty("status_code")
    private int statusCode;

    //    @JsonProperty("message")
    private String message;

    //    @JsonProperty("extra")
    private Pair<String, Object> extra;


    ResponseMessage(int statusCode, String message) {
        this.statusCode = statusCode;
        this.message = message;
        this.extra = null;
    }

    public ResponseMessage setExtra(Pair<String, Object> extra) {
        this.extra = extra;
        return this;
    }


    public int getStatusCode() {
        return statusCode;
    }

    public String getMessage() {
        return message;
    }

    public Pair<String, Object> getExtra() {
        return extra;
    }

    public JsonObject toJson() {
        extra = null;
        return JsonObject.mapFrom(this);
    }

    public JsonObject toJsonWithExtra() {
        return JsonObject.mapFrom(this);
    }

    public static class ResponseMessageSerializer extends JsonSerializer<ResponseMessage> {

        @Override
        public void serialize(ResponseMessage value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
            gen.writeStartObject();

            gen.writeFieldName("statusCode");
            gen.writeNumber(value.getStatusCode());

            gen.writeFieldName("message");
            gen.writeString(value.getMessage());

            if (value.getExtra() != null) {
                gen.writeFieldName(value.getExtra().first);
                gen.writeObject(value.getExtra().second);
            }
            gen.writeEndObject();
        }
    }
}
