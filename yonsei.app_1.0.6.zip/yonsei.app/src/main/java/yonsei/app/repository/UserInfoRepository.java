package yonsei.app.repository;

import io.vertx.core.json.JsonObject;
import redis.clients.jedis.Jedis;
import yonsei.app.common.TextUtils;
import yonsei.app.repository.db.RedisBase;

public class UserInfoRepository extends RedisBase {

    private static UserInfoRepository sInstance = new UserInfoRepository();
    private static final String KEY_NAME = "UserInfo";

    public static UserInfoRepository getInstance() {
        return sInstance;
    }

    public void addProfile(String uid, JsonObject value) {
        try (Jedis jedis = getJedis()) {
            jedis.hsetnx(KEY_NAME, KeyUtils.profile(uid), value.encode());
        }
    }

    public JsonObject getProfile(String uid) {
        JsonObject value = new JsonObject();
        try (Jedis jedis = getJedis()) {
            String profile = jedis.hget(KEY_NAME, KeyUtils.profile(uid));
            if (!TextUtils.isEmpty(profile)) {
                value = new JsonObject(profile);
            }
        }
        return value;
    }

    public void updateProfile(String uid, JsonObject newValue) {
        try (Jedis jedis = getJedis()) {
            JsonObject mergeValue = getProfile(uid);
            mergeValue.mergeIn(newValue);
            jedis.hset(KEY_NAME, KeyUtils.profile(uid), mergeValue.encode());
        }
    }

    public void deleteProfile(String uid) {
        try (Jedis jedis = getJedis()) {
            jedis.hdel(KEY_NAME, KeyUtils.profile(uid));
        }
    }
}
