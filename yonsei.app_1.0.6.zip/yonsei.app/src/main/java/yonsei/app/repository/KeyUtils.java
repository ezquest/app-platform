package yonsei.app.repository;

public final class KeyUtils {

    public static String uid(String uid) {
        return "uid:" + uid;
    }

    static String id(String id) {
        return "id:" + id + ":uid";
    }

    static String sessionId(String uid) {
        return "uid:" + uid + ":sessionId";
    }

    static String sessionIdKey(String sessionId) {
        return "sessionId:" + sessionId;
    }

    static String profile(String uid) {
        return "uid:" + uid + ":profile";
    }

    static String post(String pid) {
        return "pid:" + pid;
    }

    static String posts(String uid) {
        return "uid:" + uid + ":posts";
    }

    static String mentions(String uid) {
        return "uid:" + uid + ":mentions";
    }

    static String alsoFollowed(String uid, String targetUid) {
        return "uid:" + uid + ":also:uid:" + targetUid;
    }

    static String commonFollowers(String uid, String targetUid) {
        return "uid:" + uid + ":common:uid:" + targetUid;
    }

    static String following(String uid) {
        return "uid:" + uid + ":following";
    }

    static String followers(String uid) {
        return "uid:" + uid + ":followers";
    }

    static String timeline(String uid) {
        return "uid:" + uid + ":timeline";
    }

    static String timeline() {
        return "timeline";
    }
}
