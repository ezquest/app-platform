package yonsei.app.repository;

import io.vertx.core.json.JsonObject;
import redis.clients.jedis.Jedis;
import yonsei.app.repository.db.RedisBase;

public class PostRepository extends RedisBase {

    private static PostRepository sInstance = new PostRepository();
    private static final String KEY_NAME = "Post";
    private static final String NEXT_POST_ID_KEY_NAME = "nextPostId";

    public static PostRepository getInstance() {
        return sInstance;
    }

    public void addPost(String uid, JsonObject value) {
        try (Jedis jedis = getJedis()) {
            String pid = String.valueOf(getNextPostId());
            jedis.hsetnx(KEY_NAME, KeyUtils.profile(uid), value.encode());
        }
    }

    public long getNextPostId() {
        long nextUserIndex;
        try (Jedis jedis = getJedis()) {
            nextUserIndex = jedis.incr(NEXT_POST_ID_KEY_NAME);
        }
        return nextUserIndex;
    }
}
