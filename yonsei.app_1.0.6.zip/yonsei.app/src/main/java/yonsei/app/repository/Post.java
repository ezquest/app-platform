package yonsei.app.repository;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(prefix = "m")
public class Post {
    private String mContent;
    private String mUid;
    private String mTime = String.valueOf(System.currentTimeMillis());
    private String mReplyPid;
    private String mReplyUid;
}
