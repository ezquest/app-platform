package yonsei.app.repository;

import io.vertx.core.json.JsonObject;
import redis.clients.jedis.Jedis;
import yonsei.app.repository.db.RedisBase;

public class UserRepository extends RedisBase {

    private static UserRepository sInstance = new UserRepository();
    private static final String KEY_NAME = "Auth";
    private static final String NEXT_USER_ID_KEY_NAME = "nextUserId";

    public static UserRepository getInstance() {
        return sInstance;
    }


    public String addUser(String id, String password) {
        String uid = null;
        try (Jedis jedis = getJedis()) {
            JsonObject value = new JsonObject();
            uid = String.valueOf(getNextUserId());
            value.put("id", id);
            value.put("password", password);
            jedis.hsetnx(KEY_NAME, KeyUtils.uid(uid), value.encode());
            jedis.hsetnx(KEY_NAME, KeyUtils.id(id), uid);
        }
        return uid;
    }

    public JsonObject getUser(String uid) {
        JsonObject value = null;
        try (Jedis jedis = getJedis()) {
            value = new JsonObject(jedis.hget(KEY_NAME, KeyUtils.uid(uid)));
        }
        return value;
    }

    public JsonObject getUserById(String id) {
        JsonObject value = null;
        try (Jedis jedis = getJedis()) {
            String uid = jedis.hget(KEY_NAME, KeyUtils.id(id));
            if (uid == null) {
                return null;
            }
            value = new JsonObject(jedis.hget(KEY_NAME, KeyUtils.uid(uid)));
        }
        return value;
    }

    public String findUidById(String id) {
        String value = null;
        try (Jedis jedis = getJedis()) {
            value = jedis.hget(KEY_NAME, KeyUtils.id(id));
        }
        return value;
    }

    public boolean isIdValid(String id) {
        boolean value = false;
        try (Jedis jedis = getJedis()) {
            value = jedis.hexists(KEY_NAME, KeyUtils.id(id));
        }
        return value;
    }

    public void deleteUser(String uid) {
        try (Jedis jedis = getJedis()) {
            JsonObject user = new JsonObject(jedis.hget(KEY_NAME, KeyUtils.uid(uid)));
            String id = user.getString("id");
            jedis.hdel(KEY_NAME, KeyUtils.id(id));
            jedis.hdel(KEY_NAME, KeyUtils.uid(uid));
        }
    }

    public long getNextUserId() {
        long nextUserId;
        try (Jedis jedis = getJedis()) {
            nextUserId = jedis.incr(NEXT_USER_ID_KEY_NAME);
        }
        return nextUserId;
    }
}
