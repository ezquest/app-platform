package yonsei.app.repository.db;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import yonsei.app.common.Config;

public class RedisDbPool {

    private JedisPool jedisPool;
    private static RedisDbPool sInstance = new RedisDbPool();

    public static RedisDbPool getInstance() {
        return sInstance;
    }

    RedisDbPool() {
        jedisPool = initPool(Config.REDIS_HOST, Config.REDIS_PORT, Config.REDIS_PASSWORD);
    }

    private JedisPool initPool(String host, int port, String password) {
        return new JedisPool(new JedisPoolConfig(), host, port, 10000, password);
    }

    public Jedis getJedis() {
        return jedisPool.getResource();
    }
}
