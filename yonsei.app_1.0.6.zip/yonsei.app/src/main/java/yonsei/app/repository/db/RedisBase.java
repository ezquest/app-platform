package yonsei.app.repository.db;

import redis.clients.jedis.Jedis;

public abstract class RedisBase {

    protected Jedis getJedis() {
        return RedisDbPool.getInstance().getJedis();
    }
}
