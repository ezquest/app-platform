package yonsei.app.repository;

import redis.clients.jedis.Jedis;
import yonsei.app.repository.db.RedisBase;

import java.util.UUID;

public class SessionIdRepository extends RedisBase {

    private static SessionIdRepository sInstance = new SessionIdRepository();
    private static final String KEY_NAME = "SessionId";

    public static SessionIdRepository getInstance() {
        return sInstance;
    }


    public String addSession(String uid) {
        String sessionId = null;
        try (Jedis jedis = getJedis()) {
            sessionId = UUID.randomUUID().toString();
            jedis.hsetnx(KEY_NAME, KeyUtils.sessionId(uid), sessionId);
            jedis.hsetnx(KEY_NAME, KeyUtils.sessionIdKey(sessionId), uid);
        }
        return sessionId;
    }

    public void deleteSession(String uid) {
        try (Jedis jedis = getJedis()) {
            String sessionId = jedis.hget(KEY_NAME, KeyUtils.sessionId(uid));
            jedis.hdel(KEY_NAME, KeyUtils.sessionId(uid));
            jedis.hdel(KEY_NAME, KeyUtils.sessionIdKey(sessionId));
        }
    }

    public void deleteSessionBySessionId(String sessionId) {
        try (Jedis jedis = getJedis()) {
            String uid = jedis.hget(KEY_NAME, KeyUtils.sessionIdKey(sessionId));
            jedis.hdel(KEY_NAME, KeyUtils.sessionId(uid));
            jedis.hdel(KEY_NAME, KeyUtils.sessionIdKey(sessionId));
        }
    }

    public String getUid(String sessionId) {
        String value = null;
        try (Jedis jedis = getJedis()) {
            value = jedis.hget(KEY_NAME, KeyUtils.sessionIdKey(sessionId));
        }
        return value;
    }
}
