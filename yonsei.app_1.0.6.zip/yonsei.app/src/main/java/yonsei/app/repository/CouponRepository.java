package yonsei.app.repository;

import io.vertx.core.json.JsonObject;
import redis.clients.jedis.Jedis;
import yonsei.app.repository.db.RedisBase;

public class CouponRepository extends RedisBase {

    private static CouponRepository sInstance = new CouponRepository();
    private static final String KEY_NAME = "Coupon";
    private static final String NEXT_COUPON_ID_KEY_NAME = "nextCouponId";

    public static CouponRepository getInstance() {
        return sInstance;
    }

    public void addCoupon(String uid, JsonObject value) {
        try (Jedis jedis = getJedis()) {
            String cid = String.valueOf(getNextCouponId());
            jedis.hsetnx(KEY_NAME, KeyUtils.profile(uid), value.encode());
        }
    }

    public long getNextCouponId() {
        long nextUserIndex;
        try (Jedis jedis = getJedis()) {
            nextUserIndex = jedis.incr(NEXT_COUPON_ID_KEY_NAME);
        }
        return nextUserIndex;
    }
}
