package app.platform.com.couponbook.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import app.platform.com.couponbook.R;
import app.platform.com.couponbook.coupon.data.CouponJsonData;
import app.platform.com.couponbook.db.SessionTable;
import app.platform.com.couponbook.server.RequestHelper;
import app.platform.com.couponbook.server.ServerRequestManager;
import app.platform.com.couponbook.store.StoreItem;
import app.platform.com.couponbook.util.ResourceUtils;
import app.platform.com.couponbook.view.fragment.CouponFragment;
import app.platform.com.couponbook.view.fragment.HomeFragment;
import app.platform.com.couponbook.view.fragment.NotificationFragment;
import app.platform.com.couponbook.view.fragment.StoreMapFragment;
import app.platform.com.couponbook.view.widget.CustomViewPager;
import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity2 extends AppCompatActivity {
    private static final int REQUEST_SIGN_IN = 100;
    private static final int REQUEST_OPEN_STORE_MANAGER = 200;
    private static final String TAG = "YS-MainActivity2";

    @BindView(R.id.main_view_pager)
    CustomViewPager _viewPager;

    @BindView(R.id.main_navigation)
    BottomNavigationView _navigation;

    private AppFragmentPageAdapter mPageAdapter;


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.main_bottom_menu_navigation_home:
                    _viewPager.setCurrentItem(0);
                    return true;
                case R.id.main_bottom_menu_navigation_dashboard:
                    _viewPager.setCurrentItem(1);
                    return true;
                case R.id.main_bottom_menu_navigation_notifications:
                    _viewPager.setCurrentItem(2);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ButterKnife.bind(this);
        Toolbar toolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        mPageAdapter = new AppFragmentPageAdapter(getSupportFragmentManager());

        _viewPager.setAdapter(mPageAdapter);
        _viewPager.setOffscreenPageLimit(mPageAdapter.getCount() - 1);
        _viewPager.setEnabled(false);
        _navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

//        if (!SessionTable.getInstance().hasSession()) {
//            Intent intent = new Intent(this, SignInActivity.class);
//            startActivityForResult(intent, REQUEST_SIGN_IN);
//        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_tool_bar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.main_tool_bar_menu_user_info) {
//            testNetwork();
            Snackbar.make(_navigation, "Some text", Snackbar.LENGTH_LONG).show();
//            Intent intent = new Intent(this, UserInfoActivity.class);
//            startActivity(intent);
            return true;
        } else if (id == R.id.main_tool_bar_menu_store_manager) {
            startActivityForResult(new Intent(this, StoreManagerActivity.class), REQUEST_OPEN_STORE_MANAGER);
        }
        return super.onOptionsItemSelected(item);
    }

    private void testNetwork() {
        String sessionId = SessionTable.getInstance().get();
//        JsonObject coupon = new JsonObject();
//        coupon.addProperty("title", "abc");
//        coupon.addProperty("price", 123);
        CouponJsonData.UploadCouponJsonType coupon = new CouponJsonData.UploadCouponJsonType();
        coupon.title = "Test Title";
        coupon.description = "Test Description";
        coupon.price = 1234;
        coupon.bannerImage = ResourceUtils.getStringAsBase64(R.drawable.b1_320x320_95);
        JsonObject content = RequestHelper.makePostCouponRequest(sessionId, (JsonObject) new Gson().toJsonTree(coupon));
        ServerRequestManager.getInstance().requestWithJson(content, new ServerRequestManager.ServerCallback() {
            @Override
            public void onFailure(String message) {
            }

            @Override
            public void onResponse(JsonObject result) {
            }
        });
    }

    private static class AppFragmentPageAdapter extends FragmentPagerAdapter {


        public AppFragmentPageAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0:
//                    return HomeFragment.newInstance();
                    return StoreMapFragment.newInstance();
                case 1:
                    return CouponFragment.newInstance();
                case 2:
                    return NotificationFragment.newInstance();
            }
            return null;
        }

        @Override
        public int getCount() {
            return 3;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        Log.d(TAG, "onActivityResult.requestCode=" + requestCode + ", resultCode=" + resultCode);
        if (requestCode == REQUEST_OPEN_STORE_MANAGER) {
            if (resultCode == RESULT_OK) {
//                StoreItem storeItem = data.getParcelableExtra("StoreItem");
//                Log.d(TAG, storeItem.toString());
                Fragment fragment = (Fragment) mPageAdapter.instantiateItem(findViewById(R.id.main_view_pager), 0);
                if (fragment instanceof StoreMapFragment) {
//                    ((StoreMapFragment) fragment).addStoreMarker(storeItem);
                    ((StoreMapFragment) fragment).updateStoreMarker();
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
