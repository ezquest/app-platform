package app.platform.com.couponbook.coupon;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import app.platform.com.couponbook.R;
import app.platform.com.couponbook.coupon.type.ContentCoupon;
import app.platform.com.couponbook.coupon.type.Coupon;
import app.platform.com.couponbook.coupon.type.HeaderCoupon;
import butterknife.BindView;
import butterknife.ButterKnife;

public class CouponAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final String TAG = "YS-CouponAdapter";
    private Context mContext;
    private List<Coupon> mCouponList;

    public CouponAdapter(Context context, List<Coupon> couponList) {
        mContext = context;
        mCouponList = couponList;
    }

    @Override
    public int getItemViewType(int position) {
        return mCouponList.get(position).getType().ordinal();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int type) {
        View view;
        if (type == Coupon.Type.HEADER.ordinal()) {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.coupon_card_header,
                    viewGroup, false);
            return new HeaderViewHolder(view);
        } else {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.coupon_card,
                    viewGroup, false);
            return new ContentViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {
        if (mCouponList.get(position).getType() == Coupon.Type.HEADER) {
            HeaderCoupon content = (HeaderCoupon) mCouponList.get(position);
            HeaderViewHolder view = (HeaderViewHolder) viewHolder;
            view._titleOne.setText(content.titleOne);
            view._infoOne.setText(content.infoOne);
            view._titleTwo.setText(content.titleTwo);
            view._infoTwo.setText(content.infoTwo);
            Glide.with(mContext).load(content.headerImageUrl).into(view._headerImageUrl);
        } else {
            ContentCoupon content = (ContentCoupon) mCouponList.get(position);
            ContentViewHolder view = (ContentViewHolder) viewHolder;
            view._mainTitle.setText(content.mainTitle);
            view._mainInfo.setText(content.mainInfo);
            view._mainDescription.setText(content.mainDescription);
            if (content.mainImageUrl.contains("R.drawable")) {
                String imageName = content.mainImageUrl.replace("R.drawable.", "");
                int imageResId = mContext.getResources().getIdentifier(imageName, "drawable", mContext.getPackageName());
                Glide.with(mContext).load(imageResId).into(view._mainImage);
            } else {
                Glide.with(mContext).load(content.mainImageUrl).into(view._mainImage);
            }
            view._subTitleOne.setText(content.subTitleOne);
            view._subInfoOne.setText(content.subInfoOne);
            view._subTitleTwo.setText(content.subTitleTwo);
            view._subInfoTwo.setText(content.subInfoTwo);
            view._subTitleThree.setText(content.subTitleThree);
            view._subInfoThree.setText(content.subInfoThree);
        }
    }

    @Override
    public int getItemCount() {
        return (mCouponList != null) ? mCouponList.size() : 0;
    }

    public static class HeaderViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.coupon_card_header_1_title_text_view)
        TextView _titleOne;
        @BindView(R.id.coupon_card_header_1_info_text_view)
        TextView _infoOne;
        @BindView(R.id.coupon_card_header_2_title_text_view)
        TextView _titleTwo;
        @BindView(R.id.coupon_card_header_2_info_text_view)
        TextView _infoTwo;
        @BindView(R.id.coupon_card_header_header_image_view)
        ImageView _headerImageUrl;

        public HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    public static class ContentViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.coupon_card_main_title_text_view)
        TextView _mainTitle;
        @BindView(R.id.coupon_card_main_info_text_view)
        TextView _mainInfo;
        @BindView(R.id.coupon_card_main_description_text_view)
        TextView _mainDescription;

        @BindView(R.id.coupon_card_main_image_view)
        ImageView _mainImage;

        @BindView(R.id.coupon_card_sub_1_title_text_view)
        TextView _subTitleOne;
        @BindView(R.id.coupon_card_sub_1_info_text_view)
        TextView _subInfoOne;
        @BindView(R.id.coupon_card_sub_2_title_text_view)
        TextView _subTitleTwo;
        @BindView(R.id.coupon_card_sub_2_info_text_view)
        TextView _subInfoTwo;
        @BindView(R.id.coupon_card_sub_3_title_text_view)
        TextView _subTitleThree;
        @BindView(R.id.coupon_card_sub_3_info_text_view)
        TextView _subInfoThree;


        public ContentViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
