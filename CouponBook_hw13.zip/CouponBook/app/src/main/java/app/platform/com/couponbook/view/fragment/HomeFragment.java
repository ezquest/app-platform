package app.platform.com.couponbook.view.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import app.platform.com.couponbook.R;
import app.platform.com.couponbook.coupon.CouponAdapter;
import app.platform.com.couponbook.coupon.CouponAdapter2;
import app.platform.com.couponbook.coupon.type.ContentCoupon;
import app.platform.com.couponbook.coupon.type.Coupon;
import app.platform.com.couponbook.coupon.type.HeaderCoupon;
import butterknife.BindView;
import butterknife.ButterKnife;

public class HomeFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {

    @BindView(R.id.fragment_home_coupon_recycler_view)
    RecyclerView _couponListView;

    @BindView(R.id.fragment_home_refresh_layout)
    SwipeRefreshLayout _swipeRefreshLayout;


    CouponAdapter mCouponAdapter;
    CouponAdapter2 mCouponAdapter2;
    List<Coupon> mCouponList;

    public static HomeFragment newInstance() {
        return new HomeFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

//        mCouponList = new ArrayList<>();
//        mCouponList.add(HeaderCoupon.getTestData());
//        mCouponList.addAll(ContentCoupon.getTestData(getContext()));
//        mCouponAdapter2 = new CouponAdapter2(getContext(), mCouponList);
//        _couponListView.setLayoutManager(new LinearLayoutManager(getContext()));
//        _couponListView.setAdapter(mCouponAdapter2);
//
//        _swipeRefreshLayout.setOnRefreshListener(this);
    }

    @Override
    public void onRefresh() {
        _swipeRefreshLayout.setRefreshing(false);
    }
}