package app.platform.com.couponbook.coupon.type;

public interface Coupon {
    enum Type {
        HEADER,
        CONTENT
    }
    Type getType();
}
