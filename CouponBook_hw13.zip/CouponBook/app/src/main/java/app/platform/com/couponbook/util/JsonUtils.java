package app.platform.com.couponbook.util;

import android.content.Context;
import android.content.res.Resources;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;

public final class JsonUtils {
    private JsonUtils() {
    }

    public static String getRawJsonString(Context context, int resource) {
        StringBuilder jsonString = new StringBuilder();
        Resources res = context.getResources();
        try (InputStream in = res.openRawResource(resource)) {
            try (InputStreamReader stream = new InputStreamReader(in, "utf-8");
                 BufferedReader buffer = new BufferedReader(stream)) {
                String read;
                while ((read = buffer.readLine()) != null) {
                    jsonString.append(read);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonString.toString();
    }

    public static void mergeJson(JsonObject src, JsonObject desc) {
        for (Map.Entry<String, JsonElement> e : desc.entrySet()) {
            src.add(e.getKey(), e.getValue());
        }
    }
}
