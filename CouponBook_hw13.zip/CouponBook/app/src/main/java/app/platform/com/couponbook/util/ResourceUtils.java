package app.platform.com.couponbook.util;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;

import app.platform.com.couponbook.ContextHolder;

public final class ResourceUtils {
    private ResourceUtils() {
    }

    public static String getStringAsBase64(int resource) {
        Resources res = ContextHolder.getContext().getResources();
        String imageString = null;
        try (ByteArrayOutputStream outStream = new ByteArrayOutputStream()) {
            Bitmap bitmap = BitmapFactory.decodeResource(res, resource);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outStream);
            byte[] imageBytes = outStream.toByteArray();
            imageString = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return imageString;
    }
}
