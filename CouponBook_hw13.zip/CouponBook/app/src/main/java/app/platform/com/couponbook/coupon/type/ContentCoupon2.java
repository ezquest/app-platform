package app.platform.com.couponbook.coupon.type;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

import app.platform.com.couponbook.R;
import app.platform.com.couponbook.coupon.data.CouponJsonData;
import app.platform.com.couponbook.util.JsonUtils;

public class ContentCoupon2 implements Coupon {
    public String title;
    public String description;
    public String bannerImageUrl;
    public long expiryDate;
    public int price;
    public int originalPrice;
    public int totalQuantity;
    public int orderQuantity;

    public ContentCoupon2(CouponJsonData.RemoteCouponJsonType2 couponJsonType) {
        this.title = couponJsonType.title;
        this.description = couponJsonType.description;
        this.bannerImageUrl = couponJsonType.bannerImageUrl;
        this.expiryDate = couponJsonType.expiryDate;
        this.price = couponJsonType.price;
        this.originalPrice = couponJsonType.originalPrice;
        this.totalQuantity = couponJsonType.totalQuantity;
        this.orderQuantity = couponJsonType.orderQuantity;
    }

    @Override
    public Type getType() {
        return Type.CONTENT;
    }

    public static List<ContentCoupon2> getTestData(Context context) {
        String jsonString = JsonUtils.getRawJsonString(context, R.raw.remote_content_coupon2);
        List<CouponJsonData.RemoteCouponJsonType2> couponJsonTypes = new Gson().fromJson(jsonString,
                new TypeToken<List<CouponJsonData.RemoteCouponJsonType2>>() {
                }.getType());
        List<ContentCoupon2> contentCoupons = new ArrayList<>();
        for (CouponJsonData.RemoteCouponJsonType2 couponJsonType : couponJsonTypes) {
            contentCoupons.add(new ContentCoupon2(couponJsonType));
        }
        return contentCoupons;
    }
}
