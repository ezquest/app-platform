package app.platform.com.couponbook;

public final class Config {
    private Config() {
    }

    public static final String SERVER_URL = "YOUR_SERVER_ADDRESS";
    public static final String API_KEY = "YOUR_API_KEY";
}
