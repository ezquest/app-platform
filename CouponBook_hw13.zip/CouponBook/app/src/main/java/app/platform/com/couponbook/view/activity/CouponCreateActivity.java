package app.platform.com.couponbook.view.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import app.platform.com.couponbook.R;
import butterknife.ButterKnife;

public class CouponCreateActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);


    }
}
