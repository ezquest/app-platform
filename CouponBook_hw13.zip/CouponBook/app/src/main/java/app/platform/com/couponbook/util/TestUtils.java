package app.platform.com.couponbook.util;

import android.util.Log;

import app.platform.com.couponbook.db.StoreTable;
import app.platform.com.couponbook.store.StoreItem;

public final class TestUtils {
    private static final String TAG = "YS-" + "TestUtils";

    private TestUtils() {
    }

    private static void createTestStoreItems() {
        Log.d(TAG, "createTestStoreItems+");
        StoreTable.getInstance().put(new StoreItem("국회대로", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.530260, 126.919549));
        StoreTable.getInstance().put(new StoreItem("신세계영등포B2", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.517162, 126.905608));
        StoreTable.getInstance().put(new StoreItem("성신여대정문", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.590910, 127.018800));
        StoreTable.getInstance().put(new StoreItem("엔터식스", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.56175811, 127.0383328));
        StoreTable.getInstance().put(new StoreItem("SSG마켓도곡R", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.490298, 127.054895));
        StoreTable.getInstance().put(new StoreItem("숙대", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.54460479, 126.9672252));
        StoreTable.getInstance().put(new StoreItem("뉴코아강남", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.51031339, 127.0069582));
        StoreTable.getInstance().put(new StoreItem("정부서울청사R", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.574411, 126.973571));
        StoreTable.getInstance().put(new StoreItem("송파나루역DT", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.510793, 127.1102658));
        StoreTable.getInstance().put(new StoreItem("석촌서호", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.5063929, 127.0964684));
        StoreTable.getInstance().put(new StoreItem("아크로힐스논현", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.50898041, 127.0403869));
        StoreTable.getInstance().put(new StoreItem("교대", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.4923611, 127.0142207));
        StoreTable.getInstance().put(new StoreItem("북촌로", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.579462, 126.986431));
        StoreTable.getInstance().put(new StoreItem("가락본동", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.494895, 127.118785));
        StoreTable.getInstance().put(new StoreItem("문정하비오", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.481925, 127.123446));
        StoreTable.getInstance().put(new StoreItem("논현힐탑", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.5115577, 127.03226199999994));
        StoreTable.getInstance().put(new StoreItem("대한극장", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.56105065, 126.9952735));
        StoreTable.getInstance().put(new StoreItem("스페이스본", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.57532212, 126.9692494));
        StoreTable.getInstance().put(new StoreItem("사가정역", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.579594, 127.087966));
        StoreTable.getInstance().put(new StoreItem("서소문", "스타벅스").setStoreImageUrl("R.drawable.store_starbucks_logo").setLatLng(37.5633773, 126.97551290000001));
        Log.d(TAG, "createTestStoreItems-");
    }
}
