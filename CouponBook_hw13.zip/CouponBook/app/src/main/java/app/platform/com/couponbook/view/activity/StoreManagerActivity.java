package app.platform.com.couponbook.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.List;

import app.platform.com.couponbook.R;
import app.platform.com.couponbook.db.StoreTable;
import app.platform.com.couponbook.store.StoreItemAdapter;
import app.platform.com.couponbook.store.StoreItem;
import app.platform.com.couponbook.util.TestUtils;
import butterknife.BindView;
import butterknife.ButterKnife;

public class StoreManagerActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {
    private static final String TAG = "YS-StoreManagerActivity";

    private static final int REQUEST_ADD_STORE = 300;

    @BindView(R.id.store_manager_store_refresh_layout)
    SwipeRefreshLayout _swipeRefreshLayout;

    @BindView(R.id.store_manager_store_recycler_view)
    RecyclerView _storeListView;

    @BindView(R.id.common_toolbar)
    Toolbar _mToolbar;

    StoreItemAdapter mStoreItemAdapter;
    List<StoreItem> mStoreItemList = new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_manager);
        ButterKnife.bind(this);
        setSupportActionBar(_mToolbar);

        initTitleBar();

        mStoreItemList.addAll(StoreTable.getInstance().getAllAsStoreItemList());
        mStoreItemAdapter = new StoreItemAdapter(this, mStoreItemList);
        _storeListView.setAdapter(mStoreItemAdapter);
        _storeListView.setLayoutManager(new LinearLayoutManager(this));
        _swipeRefreshLayout.setOnRefreshListener(this);
    }


    private void initTitleBar() {
        _mToolbar.getMenu().clear();
        _mToolbar.inflateMenu(R.menu.store_manager_tool_bar_menu);
        getSupportActionBar().setTitle("Store Manager");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onRefresh() {
        _swipeRefreshLayout.setRefreshing(false);
    }

    @Override
    public void onBackPressed() {
        if (mStoreItemAdapter.isSelectionMode()) {
            mStoreItemAdapter.clearSelectionMode();
            initTitleBar();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.store_manager_tool_bar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.store_manager_selection_mode_tool_bar_delete) {
            if (mStoreItemAdapter.getSelectedItemCount() >= 1) {
                new AlertDialog.Builder(this)
                        .setTitle("Delete")
                        .setMessage("Do you want to delete?")
                        .setPositiveButton("Delete", (dialog, which) -> {
                            mStoreItemAdapter.removeItem();
                            initTitleBar();
                            dialog.dismiss();
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> {
                            mStoreItemAdapter.clearSelectionMode();
                            initTitleBar();
                            dialog.dismiss();
                        }).create().show();
            }

        } else if (item.getItemId() == R.id.store_manager_tool_bar_menu_add_store) {
            startActivityForResult(new Intent(this, StoreAddActivity.class), REQUEST_ADD_STORE);
        }
        return super.onOptionsItemSelected(item);
    }

    public void prepareToolbar() {
        _mToolbar.getMenu().clear();
        _mToolbar.inflateMenu(R.menu.store_manager_selection_mode_tool_bar_menu);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        updateToolbar();
    }

    public void updateToolbar() {
        int size = mStoreItemAdapter.getSelectedItemCount();
        getSupportActionBar().setTitle(size + " items(s) selected");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        Log.d(TAG, "onActivityResult.requestCode=" + requestCode + ", resultCode=" + resultCode);
        if (requestCode == REQUEST_ADD_STORE) {
            if (resultCode == RESULT_OK) {
//                StoreItem storeItem = data.getParcelableExtra("StoreItem");
//                mStoreItemAdapter.addItem(storeItem);
                mStoreItemAdapter.setStoreList(StoreTable.getInstance().getAllAsStoreItemList());
                setResult(RESULT_OK, data);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}

