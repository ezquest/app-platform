package app.platform.com.couponbook.view.fragment;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.List;

import app.platform.com.couponbook.R;
import app.platform.com.couponbook.db.StoreTable;
import app.platform.com.couponbook.store.StoreItem;
import app.platform.com.couponbook.util.TestUtils;
import butterknife.BindView;
import butterknife.ButterKnife;

public class StoreMapFragment extends Fragment implements OnMapReadyCallback {
    @BindView(R.id.fragment_map_map)
    MapView _mapView;

    private GoogleMap _googleMap;

    private static final int PERMISSIONS_REQUEST_CODE = 100;
    private static final String[] REQUIRED_PERMISSIONS = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
    };

    public static StoreMapFragment newInstance() {
        return new StoreMapFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_map, container, false);
        ButterKnife.bind(this, view);
        _mapView.onCreate(savedInstanceState);
        _mapView.onResume();
        _mapView.getMapAsync(this);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    private boolean checkPermission() {
        int hasFineLocationPermission = ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION);
        int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION);

        return (hasFineLocationPermission == PackageManager.PERMISSION_GRANTED &&
                hasCoarseLocationPermission == PackageManager.PERMISSION_GRANTED);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PERMISSIONS_REQUEST_CODE) {
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
            }
            if (_googleMap != null && checkPermission()) {
                _googleMap.setMyLocationEnabled(true);
            }
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        _googleMap = googleMap;

        if (checkPermission()) {
            _googleMap.setMyLocationEnabled(true);
        } else {
            ActivityCompat.requestPermissions(getActivity(), REQUIRED_PERMISSIONS, PERMISSIONS_REQUEST_CODE);
        }
        updateStoreMarker();
    }

    private MarkerOptions makeStoreMarker(double lat, double lng, String name, String info) {
        LatLng latLng = new LatLng(lat, lng);
        MarkerOptions options = new MarkerOptions();
        options.position(latLng);
        options.title(name);
        options.snippet(info);
        options.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_coffee));

        return options;
    }

    private MarkerOptions makeStoreMarker(StoreItem storeItem) {
        LatLng latLng = new LatLng(storeItem.mStoreLat, storeItem.mStoreLng);
        MarkerOptions options = new MarkerOptions();
        options.position(latLng);
        options.title(storeItem.mStoreName);
        options.snippet(storeItem.mStoreInfo);
        if ((System.currentTimeMillis() - storeItem.mCreateTime) < 1000 * 60 * 60 * 24) {
            options.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_coffee_new));
        } else {
            options.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_coffee));
        }

        return options;
    }

    public void addStoreMarker(StoreItem item) {
        _googleMap.addMarker(makeStoreMarker(item));
    }

    public void updateStoreMarker() {
        _googleMap.clear();
        LatLngBounds.Builder latLngBounds = new LatLngBounds.Builder();
        List<StoreItem> itemList = StoreTable.getInstance().getAllAsStoreItemList();
        for (StoreItem item : itemList) {
            _googleMap.addMarker(makeStoreMarker(item));
            latLngBounds.include(new LatLng(item.mStoreLat, item.mStoreLng));
        }
        _googleMap.moveCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds.build(), 30));
    }
}