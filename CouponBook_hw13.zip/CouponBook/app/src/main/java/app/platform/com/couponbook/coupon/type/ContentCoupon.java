package app.platform.com.couponbook.coupon.type;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

import app.platform.com.couponbook.R;
import app.platform.com.couponbook.coupon.data.CouponJsonData;
import app.platform.com.couponbook.util.JsonUtils;

public class ContentCoupon implements Coupon {
    public String mainTitle;
    public String mainInfo;
    public String mainDescription;
    public String mainImageUrl;

    public String subTitleOne;
    public String subInfoOne;
    public String subTitleTwo;
    public String subInfoTwo;
    public String subTitleThree;
    public String subInfoThree;

    public ContentCoupon(CouponJsonData.RemoteCouponJsonType couponJsonType) {
        this.mainTitle = couponJsonType.mainTitle;
        this.mainInfo = couponJsonType.mainInfo;
        this.mainDescription = couponJsonType.mainDescription;
        this.mainImageUrl = couponJsonType.mainImageUrl;
        this.subTitleOne = couponJsonType.subTitleOne;
        this.subInfoOne = couponJsonType.subInfoOne;
        this.subTitleTwo = couponJsonType.subTitleTwo;
        this.subInfoTwo = couponJsonType.subInfoTwo;
        this.subTitleThree = couponJsonType.subTitleThree;
        this.subInfoThree = couponJsonType.subInfoThree;
    }

    public ContentCoupon(String mainTitle, String mainInfo, String mainDescription, String mainImageUrl,
                         String subTitleOne, String subInfoOne,
                         String subTitleTwo, String subInfoTwo,
                         String subTitleThree, String subInfoThree) {
        this.mainTitle = mainTitle;
        this.mainInfo = mainInfo;
        this.mainDescription = mainDescription;
        this.mainImageUrl = mainImageUrl;
        this.subTitleOne = subTitleOne;
        this.subInfoOne = subInfoOne;
        this.subTitleTwo = subTitleTwo;
        this.subInfoTwo = subInfoTwo;
        this.subTitleThree = subTitleThree;
        this.subInfoThree = subInfoThree;
    }

    @Override
    public Type getType() {
        return Type.CONTENT;
    }

    public static List<ContentCoupon> getTestData(Context context) {
        String jsonString = JsonUtils.getRawJsonString(context, R.raw.remote_content_coupon);
        List<CouponJsonData.RemoteCouponJsonType> couponJsonTypes = new Gson().fromJson(jsonString,
                new TypeToken<List<CouponJsonData.RemoteCouponJsonType>>() {
                }.getType());
        List<ContentCoupon> contentCoupons = new ArrayList<>();
        for (CouponJsonData.RemoteCouponJsonType couponJsonType : couponJsonTypes) {
            contentCoupons.add(new ContentCoupon(couponJsonType));
        }
        return contentCoupons;
    }
}
