package app.platform.com.couponbook.view.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.button.MaterialButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;

import com.google.gson.JsonObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import app.platform.com.couponbook.Config;
import app.platform.com.couponbook.R;
import app.platform.com.couponbook.db.StoreTable;
import app.platform.com.couponbook.server.RequestHelper;
import app.platform.com.couponbook.server.ServerRequestManager;
import app.platform.com.couponbook.store.StoreItem;
import app.platform.com.couponbook.store.StoreItemAdapter;
import app.platform.com.couponbook.view.widget.InfoItemView;
import app.platform.com.couponbook.view.widget.LoadingDialog;
import butterknife.BindView;
import butterknife.ButterKnife;

public class StoreAddActivity extends AppCompatActivity {
    private static final String TAG = "YS-" + "StoreAddActivity";

    private static final int REQUEST_TAKE_IMAGE = 10;
    private static final int REQUEST_TAKE_PHOTO = 20;

    @BindView(R.id.common_toolbar)
    Toolbar _mToolbar;

    @BindView(R.id.store_add_store_main_image_view)
    ImageView _storeMainImageView;

    @BindView(R.id.store_add_store_name_edit_text)
    TextInputEditText _storeNameEditText;

    @BindView(R.id.store_add_store_info_edit_text)
    TextInputEditText _storeInfoEditText;

    @BindView(R.id.store_add_store_address_edit_text)
    TextInputEditText _storeAddressEditText;

    @BindView(R.id.store_add_store_address_to_gps_text_view_button)
    MaterialButton _storeAddressToGpsButton;

    @BindView(R.id.store_add_store_address_lat_text_view)
    InfoItemView _storeAddressLatTextView;

    @BindView(R.id.store_add_store_address_lng_text_view)
    InfoItemView _storeAddressLngTextView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_add);
        ButterKnife.bind(this);

        initTitleBar();

        initView();
    }


    private void initTitleBar() {
        setSupportActionBar(_mToolbar);
        getSupportActionBar().setTitle("Store Add");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void initView() {
        _storeAddressToGpsButton.setOnClickListener(view -> {
            String address = _storeAddressEditText.getText().toString();
            if (TextUtils.isEmpty(address)) {
                return;
            }

            try {
                InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
            } catch (Exception e) {
                // TODO: handle exception
            }

            final LoadingDialog loadingDialog = new LoadingDialog(StoreAddActivity.this);
            loadingDialog.setMessage("Getting GPS from address...");
            loadingDialog.show();
            String url = RequestHelper.makeGeocodeRequest(address, Config.API_KEY);
            ServerRequestManager.getInstance().request(url, new ServerRequestManager.ServerCallback() {
                @Override
                public void onFailure(String message) {
                    runOnUiThread(() -> {
                        loadingDialog.dismiss();
                    });
                }

                @Override
                public void onResponse(JsonObject result) {
                    runOnUiThread(() -> {
                        loadingDialog.dismiss();
                        JsonObject ret = result.getAsJsonArray("results").get(0).getAsJsonObject();
                        JsonObject gps = ret.getAsJsonObject("geometry").getAsJsonObject("location");
                        _storeAddressLatTextView.getValueView().setText(String.valueOf(gps.get("lat")));
                        _storeAddressLngTextView.getValueView().setText(String.valueOf(gps.get("lng")));
                        addStore();
                    });
                }
            });
        });

        _storeMainImageView.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            startActivityForResult(intent, REQUEST_TAKE_IMAGE);
//            startActivityForResult(Intent.createChooser(intent, "Get Image"), REQUEST_TAKE_IMAGE);
        });
    }

    private void addStore() {
        String storeName = _storeNameEditText.getText().toString();
        String storeInfo = _storeInfoEditText.getText().toString();
        double lat = Double.parseDouble(_storeAddressLatTextView.getValueView().getText().toString());
        double lng = Double.parseDouble(_storeAddressLngTextView.getValueView().getText().toString());
        StoreItem storeItem = new StoreItem(storeName, storeInfo, System.currentTimeMillis()).setLatLng(lat, lng);
        StoreTable.getInstance().put(storeItem);

//        Intent resultIntent = new Intent();
//        resultIntent.putExtra("StoreItem", storeItem);

        Snackbar.make(findViewById(R.id.store_add_main_view), "Store successfully added", Snackbar.LENGTH_LONG).show();

        setResult(RESULT_OK, null);
//        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == REQUEST_TAKE_IMAGE && resultCode == RESULT_OK) {
            try {
                try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                    Bitmap image = BitmapFactory.decodeStream(in);
                    RoundedBitmapDrawable roundedBitmap = RoundedBitmapDrawableFactory.create(getResources(), image);
                    roundedBitmap.setCornerRadius(20);
                    _storeMainImageView.setImageDrawable(roundedBitmap);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}

