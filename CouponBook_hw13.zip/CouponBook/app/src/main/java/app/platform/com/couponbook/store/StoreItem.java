package app.platform.com.couponbook.store;

import android.support.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class StoreItem implements Comparable<StoreItem> {
    @SerializedName("createTime")
    @Expose
    public Long mCreateTime;

    @SerializedName("storeName")
    @Expose
    public String mStoreName;

    @SerializedName("storeInfo")
    @Expose
    public String mStoreInfo;

    @SerializedName("storeImageUrl")
    @Expose
    public String mStoreImageUrl;

    @SerializedName("storeLat")
    @Expose
    public Double mStoreLat;

    @SerializedName("storeLng")
    @Expose
    public Double mStoreLng;

    @NonNull
    @Override
    public String toString() {
        return "StoreItem{"
                + "mCreateTime=" + mCreateTime
                + ", mStoreName='" + mStoreName + '\''
                + ", mStoreInfo='" + mStoreInfo + '\''
                + ", mStoreImageUrl='" + mStoreImageUrl + '\''
                + ", mStoreLat=" + mStoreLat
                + ", mStoreLng=" + mStoreLng
                + '}';
    }

    public StoreItem(String storeName, String storeInfo) {
        this(storeName, storeInfo, -1);
    }

    public StoreItem(String storeName, String storeInfo, long createTime) {
        mCreateTime = createTime;
        mStoreName = storeName;
        mStoreInfo = storeInfo;
        mStoreImageUrl = null;
        mStoreLat = null;
        mStoreLng = null;
    }

    public StoreItem setStoreImageUrl(String storeImageUrl) {
        mStoreImageUrl = storeImageUrl;
        return this;
    }

    public StoreItem setLatLng(double latitude, double longitude) {
        mStoreLat = latitude;
        mStoreLng = longitude;
        return this;
    }

    @Override
    public int compareTo(@NonNull StoreItem o) {
        return mCreateTime.compareTo(o.mCreateTime);
    }
}
