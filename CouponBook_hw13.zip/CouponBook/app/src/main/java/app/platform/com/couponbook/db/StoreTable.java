package app.platform.com.couponbook.db;

import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import app.platform.com.couponbook.store.StoreItem;

public class StoreTable {
    private static final String TAG = "YS-" + "StoreTable";
    private JsonArray mData = new JsonArray();

    public static final String KEY_NAME = "storeName";
    public static final String KEY_INFO = "storeInfo";
    public static final String KEY_IMAGE_URL = "storeImageUrl";
    public static final String KEY_STORE_LNG = "storeLng";
    public static final String KEY_STORE_LAT = "storeLat";

    private static class LazyHolder {
        static final StoreTable INSTANCE = new StoreTable();
    }

    public static StoreTable getInstance() {
        return LazyHolder.INSTANCE;
    }

    public JsonObject get(int index) {
        if (mData.size() < index) {
            return null;
        }
        return mData.get(index).getAsJsonObject();
    }

    public void put(StoreItem storeItem) {
        JsonObject object = new JsonObject();
        object.addProperty("createTime", storeItem.mCreateTime);
        object.addProperty("storeName", storeItem.mStoreName);
        object.addProperty("storeInfo", storeItem.mStoreInfo);
        if (!TextUtils.isEmpty(storeItem.mStoreImageUrl)) {
            object.addProperty("storeImageUrl", storeItem.mStoreImageUrl);
        }
        object.addProperty("storeLng", storeItem.mStoreLng);
        object.addProperty("storeLat", storeItem.mStoreLat);

        mData.add(object);
    }

    public boolean update(int index, StoreItem storeItem) {
        if (mData.size() < index) {
            return false;
        }
        Log.d(TAG, new Gson().toJsonTree(storeItem).toString());
        mData.set(index, new Gson().toJsonTree(storeItem));
        return true;
    }

    public boolean remove(int index) {
        if (mData.size() < index) {
            mData.remove(index);
            return true;
        }
        return false;
    }

    public int size() {
        return mData.size();
    }

    public StoreItem getAsStoreItem(int index) {
        JsonObject item = get(index);
        if (item == null) {
            return null;
        }
        return new Gson().fromJson(get(index), StoreItem.class);
    }

    public List<StoreItem> getAllAsStoreItemList() {
//        int size = StoreTable.getInstance().size();
//        for (int i = 0; i < size; i++) {
//            JsonObject item = get(i);
//            long createTime = item.get("createTime").getAsLong();
//            String storeName = item.get("storeName").getAsString();
//            String storeInfo = item.get("storeInfo").getAsString();
//            StoreItem storeItem = new StoreItem(storeName, storeInfo, createTime);
//            if (item.has("storeImageUrl")) {
//                storeItem.setStoreImageUrl(item.get("storeImageUrl").getAsString());
//            }
//            if (item.has("storeLat") && item.has("storeLng")) {
//                storeItem.setLatLng(item.get("storeLat").getAsDouble(), item.get("storeLng").getAsDouble());
//            }
//            itemList.add(storeItem);
//        }

        List<StoreItem> storeItemList = new Gson().fromJson(mData, new TypeToken<ArrayList<StoreItem>>() {
        }.getType());
        Collections.sort(storeItemList, Collections.reverseOrder());
        return storeItemList;
    }
}
