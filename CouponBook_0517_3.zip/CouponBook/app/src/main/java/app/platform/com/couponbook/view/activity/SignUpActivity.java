package app.platform.com.couponbook.view.activity;

import android.os.Bundle;
import android.support.design.button.MaterialButton;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;

import app.platform.com.couponbook.R;
import app.platform.com.couponbook.server.RequestHelper;
import app.platform.com.couponbook.server.ServerRequestManager;
import app.platform.com.couponbook.view.widget.LoadingDialog;
import butterknife.ButterKnife;
import butterknife.BindView;

public class SignUpActivity extends AppCompatActivity {
    private static final String TAG = "YS-SignUpActivity";
    @BindView(R.id.sign_up_name_edit_text)
    TextInputEditText _nameEditText;
    @BindView(R.id.sign_up_email_edit_text)
    TextInputEditText _emailEditText;
    @BindView(R.id.sign_up_password_edit_text)
    TextInputEditText _passwordEditText;
    @BindView(R.id.sign_up_sign_up_button)
    MaterialButton _signUpButton;
    @BindView(R.id.sign_up_link_sign_in_text_view)
    TextView _signInLinkText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        ButterKnife.bind(this);

        initTitleBar();
        initViewControls();
    }

    private void initTitleBar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
//        getSupportActionBar().setTitle("Sign Up");
        ((TextView) findViewById(R.id.toolbar_title)).setText("Sign Up");
    }

    private void initViewControls() {
        _signUpButton.setOnClickListener(v -> signUp());

        _signInLinkText.setOnClickListener(v -> {
            finish();
        });
    }

    public void signUp() {
        if (!validate()) {
            onSignUpFailed();
            return;
        }

        _signUpButton.setEnabled(false);

        final LoadingDialog loadingDialog = new LoadingDialog(SignUpActivity.this);
        loadingDialog.setMessage("Creating Account...");
        loadingDialog.show();

        String name = _nameEditText.getText().toString();
        String email = _emailEditText.getText().toString();
        String password = _passwordEditText.getText().toString();

        JsonObject profile = new JsonObject();
        profile.addProperty("name", name);

        JsonObject body = RequestHelper.makeSignUpRequest(email, password, profile);
        ServerRequestManager.getInstance().requestWithJson(body, new ServerRequestManager.ServerCallback() {
            @Override
            public void onFailure(String message) {
                // onSignUpFailed();
            }

            @Override
            public void onResponse(JsonObject result) {
                runOnUiThread(() -> {
                    loadingDialog.dismiss();
                    onSignUpSuccess();
                });
            }
        });
    }

    public void onSignUpSuccess() {
        setResult(RESULT_OK, null);
        finish();
    }

    public void onSignUpFailed() {
        _signUpButton.setEnabled(true);
        Toast.makeText(getBaseContext(), "SignUp failed", Toast.LENGTH_LONG).show();
    }

    public boolean validate() {
        boolean valid = true;

        String name = _nameEditText.getText().toString();
        String email = _emailEditText.getText().toString();
        String password = _passwordEditText.getText().toString();

        if (name.isEmpty() || name.length() < 3) {
            _nameEditText.setError("at least 3 characters");
            valid = false;
        } else {
            _nameEditText.setError(null);
        }

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _emailEditText.setError("enter a valid email address");
            valid = false;
        } else {
            _emailEditText.setError(null);
        }

        if (password.isEmpty() || password.length() < 4 || password.length() > 10) {
            _passwordEditText.setError("between 4 and 10 alphanumeric characters");
            valid = false;
        } else {
            _passwordEditText.setError(null);
        }
        return valid;
    }
}
