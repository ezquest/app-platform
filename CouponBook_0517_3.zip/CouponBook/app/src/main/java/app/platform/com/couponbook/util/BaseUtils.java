package app.platform.com.couponbook.util;

public final class BaseUtils {
    private BaseUtils() {
    }
}
