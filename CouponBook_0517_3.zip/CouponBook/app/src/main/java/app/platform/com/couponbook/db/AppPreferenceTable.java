package app.platform.com.couponbook.db;

public class AppPreferenceTable {

    private static class LazyHolder {
        static final AppPreferenceTable INSTANCE = new AppPreferenceTable();
    }

    public static AppPreferenceTable getInstance() {
        return LazyHolder.INSTANCE;
    }

    public String getString(String key) {
        return SharedPreferencesHelper.getString(key);
    }

    public boolean getBoolean(String key) {
        return SharedPreferencesHelper.getBoolean(key);
    }

    public void put(String key, String value) {
        SharedPreferencesHelper.putString(key, value);
    }

    public void put(String key, boolean value) {
        SharedPreferencesHelper.putBoolean(key, value);
    }

    public void remove(String key) {
        SharedPreferencesHelper.remove(key);
    }
}
