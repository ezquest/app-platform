package app.platform.com.couponbook.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.button.MaterialButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.CheckBox;
import android.widget.TextView;

import com.google.gson.JsonObject;

import app.platform.com.couponbook.R;
import app.platform.com.couponbook.db.AppPreferenceTable;
import app.platform.com.couponbook.db.PreferenceKey;
import app.platform.com.couponbook.db.SessionTable;
import app.platform.com.couponbook.server.RequestHelper;
import app.platform.com.couponbook.server.ServerRequestManager;
import app.platform.com.couponbook.view.widget.LoadingDialog;
import butterknife.BindView;
import butterknife.ButterKnife;

public class SignInActivity extends AppCompatActivity {
    private static final String TAG = "YS-SignInActivity";
    private static final int REQUEST_SIGN_UP = 200;

    @BindView(R.id.sign_in_email_edit_text)
    TextInputEditText _emailText;
    @BindView(R.id.sign_in_password_edit_text)
    TextInputEditText _passwordText;
    @BindView(R.id.sign_in_sign_in_button)
    MaterialButton _signInButton;
    @BindView(R.id.sign_in_link_sign_up_text_view)
    TextView _signUpLinkText;
    @BindView(R.id.sign_in_keep_me_signed_in_check_box)
    CheckBox _keepMeSignedInCheckBox;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        ButterKnife.bind(this);

        initTitleBar();
        initViewControls();
    }

    private void initTitleBar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
//        getSupportActionBar().setTitle("Sign In");
        ((TextView) findViewById(R.id.toolbar_title)).setText("Sign In");
    }

    private void initViewControls() {
        _signInButton.setOnClickListener(v -> signIn());

        _signUpLinkText.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), SignUpActivity.class);
            startActivityForResult(intent, REQUEST_SIGN_UP);
        });
    }

    public void signIn() {
        if (!validate()) {
            onSignInFailed();
            return;
        }

        _signInButton.setEnabled(false);

        final LoadingDialog loadingDialog = new LoadingDialog(SignInActivity.this);
        loadingDialog.setMessage("Authenticating Account...");
        loadingDialog.show();

        String email = _emailText.getText().toString();
        String password = _passwordText.getText().toString();

        JsonObject content = RequestHelper.makeSignInRequest(email, password);
        ServerRequestManager.getInstance().requestWithJson(content, new ServerRequestManager.ServerCallback() {
            @Override
            public void onFailure(String message) {
                runOnUiThread(() -> {
                    loadingDialog.dismiss();
                    onSignInFailed();
                });
            }

            @Override
            public void onResponse(JsonObject result) {
                String sessionId = result.get("sessionId").getAsString();
                SessionTable.getInstance().put(sessionId);
                runOnUiThread(() -> {
                    loadingDialog.dismiss();
                    onSignInSuccess();
                });
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        if (requestCode == REQUEST_SIGN_UP) {
//            if (resultCode == RESULT_OK) {
//            }
//        }
    }

    @Override
    public void onBackPressed() {
        // Disable going back to the MainActivity
        moveTaskToBack(true);
    }

    public void onSignInSuccess() {
        AppPreferenceTable.getInstance().put(PreferenceKey.KEEP_ME_SIGNED_IN_KEY,
                _keepMeSignedInCheckBox.isChecked());
        finish();
    }

    public void onSignInFailed() {
        _signInButton.setEnabled(true);
        Snackbar.make(findViewById(R.id.sign_in_view),
                "Incorrect user id or password", Snackbar.LENGTH_LONG).show();
    }

    public boolean validate() {
        boolean valid = true;

        String email = _emailText.getText().toString();
        String password = _passwordText.getText().toString();

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _emailText.setError("enter a valid email address");
            valid = false;
        } else {
            _emailText.setError(null);
        }

        if (password.isEmpty() || password.length() < 4 || password.length() > 10) {
            _passwordText.setError("between 4 and 10 alphanumeric characters");
            valid = false;
        } else {
            _passwordText.setError(null);
        }
        return valid;
    }
}
