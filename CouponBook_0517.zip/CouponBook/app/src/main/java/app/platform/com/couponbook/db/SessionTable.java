package app.platform.com.couponbook.db;

public class SessionTable {
    private static final String KEY = "sessionId";

    private static class LazyHolder {
        static final SessionTable INSTANCE = new SessionTable();
    }

    public static SessionTable getInstance() {
        return LazyHolder.INSTANCE;
    }

    public String get() {
        return SharedPreferencesHelper.getString(KEY);
    }

    public void put(String session) {
        SharedPreferencesHelper.putString(KEY, session);
    }

    public void remove() {
        SharedPreferencesHelper.remove(KEY);
    }

    public boolean hasSession() {
        return SharedPreferencesHelper.hasKey(KEY);
    }
}
