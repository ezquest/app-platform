package app.platform.com.couponbook;

public final class Config {
    private Config() {
    }

    public static final String SERVER_URL = "";
}
