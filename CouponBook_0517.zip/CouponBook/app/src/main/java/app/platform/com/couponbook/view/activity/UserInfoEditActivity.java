package app.platform.com.couponbook.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.button.MaterialButton;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.text.TextUtils;
import android.widget.TextView;

import app.platform.com.couponbook.R;
import butterknife.BindView;
import butterknife.ButterKnife;

public class UserInfoEditActivity extends AppCompatActivity {
    private static final String TAG = "YS-UserInfoEditActivity";

    @BindView(R.id.user_info_edit_main_info_text_view)
    TextView _userInfoMainInfoText;

    @BindView(R.id.user_info_edit_value_edit_text)
    TextInputEditText _userInfoValueEditText;

    @BindView(R.id.user_info_edit_save_button)
    MaterialButton _userInfoSaveButton;

    private String mAction;
    private String mInfoItem;
    private String mInfoValue;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info_edit);
        ButterKnife.bind(this);

        mAction = getIntent().getAction();

        initTitleBar();
        initViewControls();
    }

    private void initTitleBar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
//        getSupportActionBar().setTitle("Profile Edit");
        ((TextView) findViewById(R.id.toolbar_title)).setText("Profile Edit");
    }

    private void initViewControls() {
        mInfoItem = getIntent().getStringExtra("item");
        mInfoValue = getIntent().getStringExtra("value");
        _userInfoValueEditText.setHint(mInfoItem);
        _userInfoValueEditText.setText(mInfoValue);

        switch (mAction) {
            case "request_edit_user_info_name":
                _userInfoValueEditText.setInputType(InputType.TYPE_TEXT_VARIATION_PERSON_NAME);
                break;
            case "request_edit_user_info_age":
                _userInfoValueEditText.setInputType(InputType.TYPE_CLASS_NUMBER);
                break;
            case "request_edit_user_info_phone":
                _userInfoValueEditText.setInputType(InputType.TYPE_CLASS_PHONE);
                break;
        }

        _userInfoSaveButton.setOnClickListener(v -> {
            Intent data = new Intent();
            if (TextUtils.equals(mInfoValue, _userInfoValueEditText.getText().toString())) {
                setResult(RESULT_CANCELED, data);
            } else {
                data.putExtra("newValue", _userInfoValueEditText.getText().toString());
                setResult(RESULT_OK, data);
            }
            finish();
        });
    }
}
