package app.platform.com.couponbook.db;

public final class PreferenceKey {

    private PreferenceKey() {}
    public static final String KEEP_ME_SIGNED_IN_KEY = "keep_me_signed_in";

}
