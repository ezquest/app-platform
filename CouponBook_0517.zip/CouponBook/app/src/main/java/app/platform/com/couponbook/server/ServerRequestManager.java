package app.platform.com.couponbook.server;

import android.support.annotation.NonNull;
import android.util.Log;


import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;

import app.platform.com.couponbook.Config;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ServerRequestManager {
    private static final String TAG = "YS-ServerRequestManager";

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private OkHttpClient httpClient = null;

    private static class LazyHolder {
        static final ServerRequestManager INSTANCE = new ServerRequestManager();
    }

    public static ServerRequestManager getInstance() {
        return LazyHolder.INSTANCE;
    }

    private ServerRequestManager() {
        httpClient = new OkHttpClient();
    }

    private Call postRequest(String content, Callback callback) {
        RequestBody body = RequestBody.create(JSON, content);
        Request request = new Request.Builder()
                .url(Config.SERVER_URL)
                .post(body)
                .build();
        Call call = httpClient.newCall(request);
        call.enqueue(callback);
        return call;
    }

    public void requestWithJson(@NonNull JsonObject content, final ServerCallback serverCallback) {

        postRequest(content.toString(), new Callback() {
            @Override
            public void onFailure(Call call, IOException error) {
                Log.d(TAG, "requestWithJson:onFailure.message=" + error.getMessage());
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                serverCallback.onFailure(error.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d(TAG, "requestWithJson:onResponse:response=" + response);

                if (response.body() == null) {
                    Log.d(TAG, "requestWithJson:onResponse=" + "response.body() is null");
                    serverCallback.onResponse(null);
                    return;
                }
                String body = response.body().string();
                Log.d(TAG, "requestWithJson:onResponse:body=" + body);
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                JsonObject result = (new JsonParser()).parse(body).getAsJsonObject();
                int status_code = result.get("statusCode").getAsInt();
                if (status_code == 200) {
                    serverCallback.onResponse(result);
                } else {
                    serverCallback.onFailure(result.get("message").getAsString());
                }
            }
        });
    }

    public interface ServerCallback {
        void onFailure(String message);

        void onResponse(JsonObject result);
    }
}
