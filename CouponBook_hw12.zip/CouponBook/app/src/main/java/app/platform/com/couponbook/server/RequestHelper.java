package app.platform.com.couponbook.server;


import com.google.gson.JsonObject;

public class RequestHelper {

    public static JsonObject makeSignInRequest(String id, String password) {
        JsonObject value = new JsonObject();
        value.addProperty("command", "Auth:SignIn");
        value.addProperty("id", id);
        value.addProperty("password", password);
        return value;
    }

    public static JsonObject makeSignUpRequest(String id, String password, JsonObject profile) {
        JsonObject value = new JsonObject();
        value.addProperty("command", "Auth:SignUp");
        value.addProperty("id", id);
        value.addProperty("password", password);
        if (profile != null) {
            value.add("profile", profile);
        }
        return value;
    }

    public static JsonObject makeSignOutRequest(String sessionId) {
        JsonObject value = new JsonObject();
        value.addProperty("command", "Auth:SignOut");
        value.addProperty("sessionId", sessionId);
        return value;
    }

    public static JsonObject makeSignDropRequest(String sessionId) {
        JsonObject value = new JsonObject();
        value.addProperty("command", "Auth:SignDrop");
        value.addProperty("sessionId", sessionId);
        return value;
    }

    public static JsonObject makeGetUserProfileRequest(String sessionId) {
        JsonObject value = new JsonObject();
        value.addProperty("command", "User:GetUserInfo");
        value.addProperty("sessionId", sessionId);

        return value;
    }

    public static JsonObject makeUpdateUserProfileRequest(String sessionId, JsonObject profile) {
        JsonObject value = new JsonObject();
        value.addProperty("command", "User:UpdateUserInfo");
        value.addProperty("sessionId", sessionId);
        if (profile != null) {
            value.add("profile", profile);
        }
        return value;
    }

    public static JsonObject makePostCouponRequest(String sessionId, JsonObject coupon) {
        JsonObject value = new JsonObject();
        value.addProperty("command", "Coupon:PostCoupon");
        value.addProperty("sessionId", sessionId);
        if (coupon != null) {
            value.add("coupon", coupon);
        }
        return value;
    }

    public static String makeGeocodeRequest(String address, String apiKey) {
        return String.format("https://maps.googleapis.com/maps/api/geocode/json?address=%s&key=%s"
                , address, apiKey);
    }
}
