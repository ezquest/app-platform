package app.platform.com.couponbook.coupon;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import app.platform.com.couponbook.R;
import app.platform.com.couponbook.coupon.type.ContentCoupon;
import app.platform.com.couponbook.coupon.type.ContentCoupon2;
import app.platform.com.couponbook.coupon.type.Coupon;
import app.platform.com.couponbook.coupon.type.HeaderCoupon;
import butterknife.BindView;
import butterknife.ButterKnife;

public class CouponAdapter3 extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final String TAG = "YS-CouponAdapter3";
    private Context mContext;
    private List<Coupon> mCouponList;

    public CouponAdapter3(Context context, List<Coupon> couponList) {
        mContext = context;
        mCouponList = couponList;
    }

    @Override
    public int getItemViewType(int position) {
        return mCouponList.get(position).getType().ordinal();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int type) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.coupon_card3,
                viewGroup, false);
        return new ContentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {
        ContentCoupon2 content = (ContentCoupon2) mCouponList.get(position);
        ContentViewHolder view = (ContentViewHolder) viewHolder;
        view._title.setText(content.title);
        view._description.setText(content.description);
        if (content.bannerImageUrl.contains("R.drawable")) {
            String imageName = content.bannerImageUrl.replace("R.drawable.", "");
            int imageResId = mContext.getResources().getIdentifier(imageName, "drawable", mContext.getPackageName());
            Glide.with(mContext).load(imageResId).into(view._bannerImage);
        } else {
            Glide.with(mContext).load(content.bannerImageUrl).into(view._bannerImage);
        }
        view._price.setText(String.valueOf(content.price));
        view._orderQuantity.setText(String.valueOf(content.orderQuantity));
    }

    @Override
    public int getItemCount() {
        return (mCouponList != null) ? mCouponList.size() : 0;
    }

    public static class ContentViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.coupon_card_style3_banner_image_view)
        ImageView _bannerImage;
        @BindView(R.id.coupon_card_style3_title_text_view)
        TextView _title;
        @BindView(R.id.coupon_card_style3_description_text_view)
        TextView _description;
        @BindView(R.id.coupon_card_style3_price_text_view)
        TextView _price;
        @BindView(R.id.coupon_card_style3_order_quantity_text_view)
        TextView _orderQuantity;


        public ContentViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
