package app.platform.com.couponbook.view.widget;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

public class LoadingDialog extends ProgressDialog {
    public LoadingDialog(Context context) {
        super(context);
        this.setIndeterminate(true);
        this.setCancelable(false);
        this.setCanceledOnTouchOutside(false);
    }

    public void dismiss(long delayMillis) {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                dismiss();
            }
        }, delayMillis);
    }
}
