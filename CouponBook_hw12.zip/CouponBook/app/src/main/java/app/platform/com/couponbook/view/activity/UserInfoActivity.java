package app.platform.com.couponbook.view.activity;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.button.MaterialButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.gson.JsonObject;

import app.platform.com.couponbook.R;
import app.platform.com.couponbook.db.SessionTable;
import app.platform.com.couponbook.server.RequestHelper;
import app.platform.com.couponbook.server.ServerRequestManager;
import app.platform.com.couponbook.view.widget.InfoItemView;
import app.platform.com.couponbook.view.widget.LoadingDialog;
import butterknife.BindView;
import butterknife.ButterKnife;

public class UserInfoActivity extends AppCompatActivity {
    private static final String TAG = "YS-UserInfoActivity";
    private static final int REQUEST_EDIT_USER_INFO_NAME = 301;
    private static final int REQUEST_EDIT_USER_INFO_AGE = 302;
    private static final int REQUEST_EDIT_USER_INFO_PHONE = 303;

    @BindView(R.id.user_info_main_info_text_view)
    TextView _userInfoMainInfoText;

    @BindView(R.id.user_info_name_container)
    InfoItemView _userInfoNameContainer;

    @BindView(R.id.user_info_age_container)
    InfoItemView _userInfoAgeContainer;

    @BindView(R.id.user_info_phone_container)
    InfoItemView _userInfoPhoneContainer;

    @BindView(R.id.user_info_email_container)
    InfoItemView _userInfoEmailContainer;

    @BindView(R.id.user_info_update_button)
    MaterialButton _updateButton;

    private JsonObject mProfile;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);
        ButterKnife.bind(this);

        initTitleBar();
        initViewControls();
        getUserProfile();
    }

    private void initTitleBar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
//        getSupportActionBar().setTitle("Profile");
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        ((TextView) findViewById(R.id.toolbar_title)).setText("Profile");
    }

    private void getUserProfile() {
        final LoadingDialog loadingDialog = new LoadingDialog(this);
        loadingDialog.setMessage("Loading...");
        loadingDialog.show();
        String sessionId = SessionTable.getInstance().get();
        JsonObject content = RequestHelper.makeGetUserProfileRequest(sessionId);
        ServerRequestManager.getInstance().requestWithJson(content, new ServerRequestManager.ServerCallback() {
            @Override
            public void onFailure(String message) {
                runOnUiThread(() -> {
                    loadingDialog.dismiss();
                    Snackbar.make(getWindow().getDecorView().getRootView(), "Test", Snackbar.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onResponse(JsonObject result) {
                mProfile = result.get("profile").getAsJsonObject();

                runOnUiThread(() -> {
                    if (mProfile.has("name")) {
                        _userInfoNameContainer.getValueView().setText(mProfile.get("name").getAsString());
                    } else {
                        _userInfoNameContainer.getValueView().setText("");
                    }

                    if (mProfile.has("age")) {
                        _userInfoAgeContainer.getValueView().setText(mProfile.get("age").getAsString());
                    } else {
                        _userInfoAgeContainer.getValueView().setText("");
                    }

                    if (mProfile.has("phone")) {
                        _userInfoPhoneContainer.getValueView().setText(mProfile.get("phone").getAsString());
                    } else {
                        _userInfoPhoneContainer.getValueView().setText("");
                    }
                    loadingDialog.dismiss();
                    View mainView = findViewById(R.id.user_info_container);
                    ObjectAnimator animator = ObjectAnimator.ofFloat(mainView, "alpha", 0.0F, 1.0F)
                            .setDuration(200L);
                    animator.start();
                });
            }
        });
    }

    private void updateUserProfile() {
        JsonObject profile = new JsonObject();
        profile.addProperty("name", _userInfoNameContainer.getValueView().getText().toString());
        profile.addProperty("age", _userInfoAgeContainer.getValueView().getText().toString());
        profile.addProperty("phone", _userInfoPhoneContainer.getValueView().getText().toString());
        String sessionId = SessionTable.getInstance().get();

        final LoadingDialog loadingDialog = new LoadingDialog(this);
        loadingDialog.setMessage("Update Profile...");
        loadingDialog.show();
        JsonObject content = RequestHelper.makeUpdateUserProfileRequest(sessionId, profile);
        ServerRequestManager.getInstance().requestWithJson(content, new ServerRequestManager.ServerCallback() {
            @Override
            public void onFailure(String message) {
                runOnUiThread(() -> {
                    loadingDialog.dismiss();
                    Snackbar.make(getWindow().getDecorView().getRootView(), "Test", Snackbar.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onResponse(JsonObject result) {
                runOnUiThread(() -> {
                    loadingDialog.dismiss();
                    finish();
                });
            }
        });
    }

    private void initViewControls() {
        _updateButton.setOnClickListener(v -> updateUserProfile());

        String sessionId = SessionTable.getInstance().get();
        Log.d(TAG, sessionId);
        String result = "SessionId" + "\n" + sessionId;
        _userInfoMainInfoText.setText(result);

        _userInfoNameContainer.setOnClickListener(mClickListener);
        _userInfoAgeContainer.setOnClickListener(mClickListener);
        _userInfoPhoneContainer.setOnClickListener(mClickListener);

        _userInfoNameContainer.getTitleView().setText("Name");
        _userInfoAgeContainer.getTitleView().setText("Age");
        _userInfoPhoneContainer.getTitleView().setText("Phone");
        _userInfoEmailContainer.getTitleView().setText("Email");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        Log.d(TAG, "onActivityResult.requestCode=" + requestCode + ", resultCode=" + resultCode);
        if (requestCode == REQUEST_EDIT_USER_INFO_NAME) {
            if (resultCode == RESULT_OK) {
                String newValue = data.getStringExtra("newValue");
                _userInfoNameContainer.getValueView().setText(newValue);
            }
        } else if (requestCode == REQUEST_EDIT_USER_INFO_AGE) {
            if (resultCode == RESULT_OK) {
                String newValue = data.getStringExtra("newValue");
                _userInfoAgeContainer.getValueView().setText(newValue);
            }
        } else if (requestCode == REQUEST_EDIT_USER_INFO_PHONE) {
            if (resultCode == RESULT_OK) {
                String newValue = data.getStringExtra("newValue");
                _userInfoPhoneContainer.getValueView().setText(newValue);
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    private final View.OnClickListener mClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View view) {
            Intent intent = new Intent(UserInfoActivity.this, UserInfoEditActivity.class);
            switch (view.getId()) {
                case R.id.user_info_name_container:
                    intent.putExtra("item", "Name");
                    intent.putExtra("value", _userInfoNameContainer.getValueView().getText());
                    intent.setAction("request_edit_user_info_name");
                    startActivityForResult(intent, REQUEST_EDIT_USER_INFO_NAME);
                    break;

                case R.id.user_info_age_container:
                    intent.putExtra("item", "Age");
                    intent.putExtra("value", _userInfoAgeContainer.getValueView().getText());
                    intent.setAction("request_edit_user_info_age");
                    startActivityForResult(intent, REQUEST_EDIT_USER_INFO_AGE);
                    break;

                case R.id.user_info_phone_container:
                    intent.putExtra("item", "Phone");
                    intent.putExtra("value", _userInfoPhoneContainer.getValueView().getText());
                    intent.setAction("request_edit_user_info_phone");
                    startActivityForResult(intent, REQUEST_EDIT_USER_INFO_PHONE);
                    break;
            }
        }
    };

}
