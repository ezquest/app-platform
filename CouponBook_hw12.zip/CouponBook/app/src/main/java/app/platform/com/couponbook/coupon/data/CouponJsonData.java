package app.platform.com.couponbook.coupon.data;

import com.google.gson.annotations.SerializedName;

public final class CouponJsonData {

    public static class RemoteCouponJsonType {
        @SerializedName("main_title")
        public String mainTitle = "";
        @SerializedName("main_info")
        public String mainInfo = "";
        @SerializedName("main_description")
        public String mainDescription = "";
        @SerializedName("main_image_url")
        public String mainImageUrl = "";
        @SerializedName("sub_title_one")
        public String subTitleOne = "";
        @SerializedName("sub_info_one")
        public String subInfoOne = "";
        @SerializedName("sub_title_two")
        public String subTitleTwo = "";
        @SerializedName("sub_info_two")
        public String subInfoTwo = "";
        @SerializedName("sub_title_three")
        public String subTitleThree = "";
        @SerializedName("sub_info_three")
        public String subInfoThree = "";
    }

    public static class RemoteCouponJsonType2 {
        public String title = "";
        public String description = "";
        public String bannerImageUrl = "";
        public long expiryDate = 0;
        public int price = 0;
        public int originalPrice = 0;
        public int totalQuantity = 0;
        public int orderQuantity = 0;
    }

    public static class UploadCouponJsonType {
        public String title = "";
        public String description = "";
        public String bannerImage = "";
        public int price = 0;
    }
}
