package app.platform.com.couponbook;

import android.app.Application;

import app.platform.com.couponbook.db.AppPreferenceTable;
import app.platform.com.couponbook.db.PreferenceKey;
import app.platform.com.couponbook.db.SessionTable;

public class AppApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        ContextHolder.setContext(this);
        boolean isKeepMeStatus = AppPreferenceTable.getInstance().getBoolean(PreferenceKey.KEEP_ME_SIGNED_IN_KEY);
        if (!isKeepMeStatus) {
            SessionTable.getInstance().remove();
        }
    }
}
