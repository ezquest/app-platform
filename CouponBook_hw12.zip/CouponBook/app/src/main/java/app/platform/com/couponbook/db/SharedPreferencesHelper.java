package app.platform.com.couponbook.db;

import android.content.Context;
import android.content.SharedPreferences;

import app.platform.com.couponbook.ContextHolder;

public class SharedPreferencesHelper {

    public static void putString(String key, String value) {
        SharedPreferences pref = ContextHolder.getContext().getSharedPreferences("pref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public static void putBoolean(String key, boolean value) {
        SharedPreferences pref = ContextHolder.getContext().getSharedPreferences("pref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }

    public static String getString(String key) {
        SharedPreferences pref = ContextHolder.getContext().getSharedPreferences("pref", Context.MODE_PRIVATE);
        return pref.getString(key, null);
    }

    public static boolean getBoolean(String key) {
        SharedPreferences pref = ContextHolder.getContext().getSharedPreferences("pref", Context.MODE_PRIVATE);
        return pref.getBoolean(key, false);
    }

    public static void remove(String key) {
        SharedPreferences pref = ContextHolder.getContext().getSharedPreferences("pref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.remove(key);
        editor.apply();
    }

    public static boolean hasKey(String key) {
        SharedPreferences pref = ContextHolder.getContext().getSharedPreferences("pref", Context.MODE_PRIVATE);
        return pref.contains(key);
    }
}
