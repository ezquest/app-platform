package app.platform.com.couponbook.server;

import android.support.annotation.NonNull;
import android.util.Log;


import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import app.platform.com.couponbook.Config;
import app.platform.com.couponbook.ContextHolder;
import app.platform.com.couponbook.R;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ServerRequestManager {
    private static final String TAG = "YS-ServerRequestManager";

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private OkHttpClient httpClient = null;

    private static class LazyHolder {
        static final ServerRequestManager INSTANCE = new ServerRequestManager();
    }

    public static ServerRequestManager getInstance() {
        return LazyHolder.INSTANCE;
    }

    private ServerRequestManager() {
        httpClient = new OkHttpClient();
    }

    private Call postRequest(String content, Callback callback) {
        RequestBody body = RequestBody.create(JSON, content);
        Request request = new Request.Builder()
                .url(Config.SERVER_URL)
                .post(body)
                .build();
        Call call = httpClient.newCall(request);
        call.enqueue(callback);
        return call;
    }

    private Call getRequest(String url, Callback callback) {
        Request request = new Request.Builder()
                .url(url)
                .build();
        Call call = httpClient.newCall(request);
        call.enqueue(callback);
        return call;
    }

    private Call postRequestWithImage(String content, Callback callback) {
        File file = new File("android.resource://" + ContextHolder.getContext().getPackageName() + "/" + R.raw.b1_320x320_95);
        RequestBody body = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("content", content)
                .addFormDataPart("image", "b1_320x320_95.jpg",
                        RequestBody.create(MediaType.parse("image/jpg"), file))
                .build();

        Request request = new Request.Builder()
                .url(Config.SERVER_URL)
                .post(body)
                .build();
        Call call = httpClient.newCall(request);
        call.enqueue(callback);
        return call;
    }

    public void requestWithJsonAndFile(@NonNull JsonObject content, final ServerCallback serverCallback) {
        postRequestWithImage(content.toString(), new Callback() {
            @Override
            public void onFailure(Call call, IOException error) {
                Log.d(TAG, "requestWithJsonAndFile:onFailure.message=" + error.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d(TAG, "requestWithJsonAndFile:onResponse:response=" + response);
                if (response.body() == null) {
                    Log.d(TAG, "requestWithJsonAndFile:onResponse=" + "response.body() is null");
                    serverCallback.onResponse(null);
                    return;
                }
                String body = response.body().string();
                Log.d(TAG, "requestWithJsonAndFile:onResponse:body=" + body);
            }
        });
    }

    public void requestWithJson(@NonNull JsonObject content, final ServerCallback serverCallback) {

        postRequest(content.toString(), new Callback() {
            @Override
            public void onFailure(Call call, IOException error) {
                Log.d(TAG, "requestWithJson:onFailure.message=" + error.getMessage());
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                serverCallback.onFailure(error.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d(TAG, "requestWithJson:onResponse:response=" + response);

                if (response.body() == null) {
                    Log.d(TAG, "requestWithJson:onResponse=" + "response.body() is null");
                    serverCallback.onResponse(null);
                    return;
                }
                String body = response.body().string();
                Log.d(TAG, "requestWithJson:onResponse:body=" + body);
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                JsonObject result = (new JsonParser()).parse(body).getAsJsonObject();
                int status_code = result.get("statusCode").getAsInt();
                if (status_code == 200) {
                    serverCallback.onResponse(result);
                } else {
                    serverCallback.onFailure(result.get("message").getAsString());
                }
            }
        });
    }

    public void request(String url, final ServerCallback callback) {
        getRequest(url, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                if (callback != null) {
                    callback.onFailure(e.getMessage());
                }
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String body = response.body().string();
                Log.d(TAG, "requestWithJson:onResponse:body=" + body);
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                JsonObject result = (new JsonParser()).parse(body).getAsJsonObject();
                if (callback != null) {
                    callback.onResponse(result);
                }
            }
        });
    }

    public interface ServerCallback {
        void onFailure(String message);

        void onResponse(JsonObject result);
    }
}
