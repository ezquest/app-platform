package app.platform.com.couponbook.store;

import java.util.ArrayList;
import java.util.List;

import app.platform.com.couponbook.R;
import app.platform.com.couponbook.coupon.type.Coupon;

public class StoreItem {
    public String storeName;
    public String storeInfo;
    public String storeImageUrl;

    public StoreItem(String storeName, String storeInfo, String storeImageUrl) {
        this.storeName = storeName;
        this.storeInfo = storeInfo;
        this.storeImageUrl = storeImageUrl;
    }

    public static List<StoreItem> getTestData() {
        List<StoreItem> itemList = new ArrayList<>();
        itemList.add(new StoreItem("Store 1", "Store 1 is good coffee shop", "R.drawable.store_logo_1"));
        itemList.add(new StoreItem("Store 2", "Store 2 is good coffee shop", "R.drawable.store_logo_2"));
        itemList.add(new StoreItem("Store 3", "Store 3 is good coffee shop", "R.drawable.store_logo_3"));
        itemList.add(new StoreItem("Store 4", "Store 4 is good coffee shop", "R.drawable.store_logo_4"));
        itemList.add(new StoreItem("Store 5", "Store 5 is good coffee shop", "R.drawable.store_logo_5"));
        itemList.add(new StoreItem("Store 6", "Store 6 is good coffee shop", "R.drawable.store_logo_6"));
        itemList.add(new StoreItem("Store 7", "Store 7 is good coffee shop", "R.drawable.store_logo_7"));
        itemList.add(new StoreItem("Store 8", "Store 8 is good coffee shop", "R.drawable.store_logo_8"));
        itemList.add(new StoreItem("Store 9", "Store 9 is good coffee shop", "R.drawable.store_logo_9"));
        itemList.add(new StoreItem("Store 10", "Store 10 is good coffee shop", "R.drawable.store_logo_10"));
        itemList.add(new StoreItem("Store 11", "Store 11 is good coffee shop", "R.drawable.store_logo_11"));
        itemList.add(new StoreItem("Store 12", "Store 12 is good coffee shop", "R.drawable.store_logo_12"));
        itemList.add(new StoreItem("Store 13", "Store 13 is good coffee shop", "R.drawable.store_logo_13"));
        itemList.add(new StoreItem("Store 14", "Store 14 is good coffee shop", "R.drawable.store_logo_14"));
        itemList.add(new StoreItem("Store 15", "Store 15 is good coffee shop", "R.drawable.store_logo_15"));
        itemList.add(new StoreItem("Store 16", "Store 16 is good coffee shop", "R.drawable.store_logo_16"));
        itemList.add(new StoreItem("Store 17", "Store 17 is good coffee shop", "R.drawable.store_logo_17"));
        itemList.add(new StoreItem("Store 18", "Store 18 is good coffee shop", "R.drawable.store_logo_18"));
        itemList.add(new StoreItem("Store 19", "Store 19 is good coffee shop", "R.drawable.store_logo_19"));
        itemList.add(new StoreItem("Store 20", "Store 20 is good coffee shop", "R.drawable.store_logo_20"));

        return itemList;
    }
}
