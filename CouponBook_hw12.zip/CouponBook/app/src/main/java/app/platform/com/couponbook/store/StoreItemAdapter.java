package app.platform.com.couponbook.store;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import app.platform.com.couponbook.R;
import app.platform.com.couponbook.view.activity.StoreManagerActivity;
import butterknife.BindView;
import butterknife.ButterKnife;

public class StoreItemAdapter extends RecyclerView.Adapter<StoreItemAdapter.ContentViewHolder> {
    private static final String TAG = "YS-StoreAdapter";
    private Context mContext;
    private boolean mIsSelectionMode = false;
    private List<StoreItem> mStoreItemList;
    private List<Integer> mSelectedItemList = new ArrayList<>();

    public StoreItemAdapter(Context context, List<StoreItem> storeList) {
        mContext = context;
        mStoreItemList = storeList;
    }

    @NonNull
    @Override
    public ContentViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int type) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.store_card,
                viewGroup, false);
        return new ContentViewHolder(mContext, view);
    }

    @Override
    public void onBindViewHolder(@NonNull ContentViewHolder viewHolder, int position) {
        viewHolder.bind(position);
    }

    @Override
    public int getItemCount() {
        return (mStoreItemList != null) ? mStoreItemList.size() : 0;
    }

    public int getSelectedItemCount() {
        return (mSelectedItemList != null) ? mSelectedItemList.size() : 0;
    }

    public boolean isSelectionMode() {
        return mIsSelectionMode;
    }

    public void clearSelectionMode() {
        mIsSelectionMode = false;
        mSelectedItemList.clear();
        notifyDataSetChanged();
    }

    public void removeItem() {
        Collections.sort(mSelectedItemList, Collections.reverseOrder());
        for (int index : mSelectedItemList) {
            Log.d(TAG, "removeItem.index=" + index);
            mStoreItemList.remove(index);
        }
        clearSelectionMode();
    }

    class ContentViewHolder extends RecyclerView.ViewHolder implements
            View.OnClickListener, View.OnLongClickListener {
        private Context mContext;

        @BindView(R.id.store_card_store_container)
        View _container;
        @BindView(R.id.store_card_store_name_text_view)
        TextView _storeName;
        @BindView(R.id.store_card_store_info_text_view)
        TextView _storeInfo;
        @BindView(R.id.store_card_store_image_view)
        ImageView _storeImage;

        ContentViewHolder(Context context, @NonNull View itemView) {
            super(itemView);
            mContext = context;
            ButterKnife.bind(this, itemView);
            _container.setOnLongClickListener(this);
            _container.setOnClickListener(this);
        }

        void bind(int position) {
            Log.d(TAG, "bind.position=" + position);
            StoreItem item = mStoreItemList.get(position);
            _container.setBackgroundColor(Color.WHITE);
            _storeName.setText(item.storeName);
            _storeInfo.setText(item.storeInfo);
            if (item.storeImageUrl.contains("R.drawable")) {
                String imageName = item.storeImageUrl.replace("R.drawable.", "");
                int imageResId = mContext.getResources().getIdentifier(imageName, "drawable", mContext.getPackageName());
                Glide.with(mContext).load(imageResId).into(_storeImage);
            } else {
                Glide.with(mContext).load(item.storeImageUrl).into(_storeImage);
            }
            if (mIsSelectionMode && mSelectedItemList.contains(position)) {
                _container.setBackgroundColor(Color.LTGRAY);
            }
        }

        void selectItem(Integer position) {
            Log.d(TAG, "selectItem.position=" + position);
            if (mIsSelectionMode) {
                if (mSelectedItemList.contains(position)) {
                    mSelectedItemList.remove(position);
                    _container.setBackgroundColor(Color.WHITE);
                } else {
                    mSelectedItemList.add(position);
                    _container.setBackgroundColor(Color.LTGRAY);
                }
            }
        }

        @Override
        public boolean onLongClick(View view) {
            mIsSelectionMode = true;
            selectItem(getAdapterPosition());
            ((StoreManagerActivity) mContext).prepareToolbar();
            return true;
        }

        @Override
        public void onClick(View view) {
            if (mIsSelectionMode) {
                selectItem(getAdapterPosition());
                ((StoreManagerActivity) mContext).updateToolbar();
            }
        }
    }
}
