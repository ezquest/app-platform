package app.platform.com.couponbook.view.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.support.design.card.MaterialCardView;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import app.platform.com.couponbook.R;

public class InfoItemView extends MaterialCardView {

    private TextView mTitleText;
    private TextView mValueText;

    public InfoItemView(Context context) {
        this(context, null);
    }

    public InfoItemView(Context context, AttributeSet attrs) {
        this(context, attrs, R.attr.materialCardViewStyle);
    }

    public InfoItemView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        inflate(getContext(), R.layout.activity_user_info_item, this);

        mTitleText = findViewById(R.id.user_info_item_title_text_view);
        mValueText = findViewById(R.id.user_info_item_value_text_view);

        TypedArray a = context.getTheme().obtainStyledAttributes(
                attrs, R.styleable.InfoItemView, 0, 0);

        setStrokeWidth(1);
        setStrokeColor(Color.parseColor("#6b000000"));
        try {
            String title = a.getString(R.styleable.InfoItemView_titleText);
            if (!TextUtils.isEmpty(title)) {
                mTitleText.setText(title);
            }

            String value = a.getString(R.styleable.InfoItemView_valueText);
            if (!TextUtils.isEmpty(value)) {
                mValueText.setText(value);
            }

            boolean isShown = a.getBoolean(R.styleable.InfoItemView_showValue, true);
            if (!isShown) {
                mValueText.setVisibility(View.GONE);
                findViewById(R.id.user_info_item_link_text_view).setVisibility(View.GONE);
            }
        } finally {
            a.recycle();
        }
    }
    public TextView getTitleView() {
        return mTitleText;
    }

    public TextView getValueView() {
        return mValueText;
    }
}
