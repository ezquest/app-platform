package app.platform.com.couponbook.coupon.type;

import app.platform.com.couponbook.R;

public class HeaderCoupon implements Coupon {
    public String titleOne;
    public String infoOne;
    public String titleTwo;
    public String infoTwo;
    public int headerImageUrl;

    public HeaderCoupon(String titleOne, String infoOne, String titleTwo, String infoTwo,
                        int headerImageUrl) {
        this.titleOne = titleOne;
        this.infoOne = infoOne;
        this.titleTwo = titleTwo;
        this.infoTwo = infoTwo;
        this.headerImageUrl = headerImageUrl;
    }

    @Override
    public Type getType() {
        return Type.HEADER;
    }

    public static HeaderCoupon getTestData() {
        HeaderCoupon headerCoupon = new HeaderCoupon("Items", "2",
                "마감임박(24시간 이내)", "0", R.drawable.cover);
        return headerCoupon;
    }
}
