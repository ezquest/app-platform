package app.platform.com.couponbook.view.activity;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.design.button.MaterialButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

import app.platform.com.couponbook.coupon.CouponAdapter;
import app.platform.com.couponbook.R;
import app.platform.com.couponbook.coupon.CouponAdapter2;
import app.platform.com.couponbook.coupon.type.ContentCoupon;
import app.platform.com.couponbook.coupon.type.Coupon;
import app.platform.com.couponbook.coupon.type.HeaderCoupon;
import app.platform.com.couponbook.db.SessionTable;
import app.platform.com.couponbook.server.RequestHelper;
import app.platform.com.couponbook.server.ServerRequestManager;
import app.platform.com.couponbook.view.widget.LoadingDialog;
import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "YS-MainActivity";
    private static final int REQUEST_SIGN_IN = 100;

    @BindView(R.id.main_coupon_recycler_view)
    RecyclerView _couponListView;

    @BindView(R.id.main_sign_out_button)
    MaterialButton _signOutButton;

    @BindView(R.id.main_sign_drop_button)
    MaterialButton _signDropButton;

    CouponAdapter mCouponAdapter;
    CouponAdapter2 mCouponAdapter2;
    List<Coupon> mCouponList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        initTitleBar();
        initViewControls();

        if (!SessionTable.getInstance().hasSession()) {
            Intent intent = new Intent(this, SignInActivity.class);
            startActivityForResult(intent, REQUEST_SIGN_IN);
        }
        mCouponList = new ArrayList<>();
        mCouponList.add(HeaderCoupon.getTestData());
        mCouponList.addAll(ContentCoupon.getTestData(this));
        mCouponAdapter2 = new CouponAdapter2(this, mCouponList);
        _couponListView.setLayoutManager(new LinearLayoutManager(this));
        _couponListView.setAdapter(mCouponAdapter2);
    }

    private void initTitleBar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
//        getSupportActionBar().setTitle("Sign Up");
        ((TextView) findViewById(R.id.toolbar_title)).setText("Coupon Book");
    }

    private void initViewControls() {

        _signOutButton.setOnClickListener(v -> {
            String sessionId = SessionTable.getInstance().get();
            final LoadingDialog loadingDialog = new LoadingDialog(MainActivity.this);
            loadingDialog.setMessage("Sign out...");
            loadingDialog.show();
            JsonObject content = RequestHelper.makeSignOutRequest(sessionId);
            ServerRequestManager.getInstance().requestWithJson(content, new ServerRequestManager.ServerCallback() {
                @Override
                public void onFailure(String message) {

                }

                @Override
                public void onResponse(JsonObject result) {
                    runOnUiThread(() -> {
                        loadingDialog.dismiss();
                        SessionTable.getInstance().remove();
                        Intent intent = new Intent(MainActivity.this, SignInActivity.class);
                        startActivityForResult(intent, REQUEST_SIGN_IN);
                    });
                }
            });
        });

        _signDropButton.setOnClickListener(v -> {
            String sessionId = SessionTable.getInstance().get();
            final LoadingDialog loadingDialog = new LoadingDialog(MainActivity.this);
            loadingDialog.setMessage("Sign drop...");
            loadingDialog.show();
            JsonObject content = RequestHelper.makeSignDropRequest(sessionId);
            ServerRequestManager.getInstance().requestWithJson(content, new ServerRequestManager.ServerCallback() {
                @Override
                public void onFailure(String message) {

                }

                @Override
                public void onResponse(JsonObject result) {
                    runOnUiThread(() -> {
                        loadingDialog.dismiss();
                        SessionTable.getInstance().remove();
                        Intent intent = new Intent(MainActivity.this, SignInActivity.class);
                        startActivityForResult(intent, REQUEST_SIGN_IN);
                    });
                }
            });
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        if (requestCode == REQUEST_SIGN_IN) {
//            if (resultCode == RESULT_OK) {
//            }
//        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_user_info) {
            Intent intent = new Intent(this, UserInfoActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
