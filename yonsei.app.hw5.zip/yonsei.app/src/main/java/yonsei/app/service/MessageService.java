package yonsei.app.service;


import io.vertx.core.json.JsonObject;
import yonsei.app.action.command.SignInCommand;
import yonsei.app.action.command.SignUpCommand;

import static yonsei.app.action.message.ResponseMessage.CommonErrorMessage;

public class MessageService {
    private static MessageService sInstance = new MessageService();

    public static MessageService getInstance() {
        return sInstance;
    }

    public JsonObject execute(JsonObject jsonBody) {
        System.out.println("[Request body]");
        System.out.println(jsonBody);
        String method = jsonBody.getString("command", "None");
        switch (method) {
            case SignInCommand.commandName:
                return new SignInCommand().execute(jsonBody);
            case SignUpCommand.commandName:
                return new SignUpCommand().execute(jsonBody);
            default:
                return JsonObject.mapFrom(CommonErrorMessage.BAD_REQUEST);
        }
    }
}
