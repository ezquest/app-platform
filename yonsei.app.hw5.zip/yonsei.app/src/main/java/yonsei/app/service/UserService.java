package yonsei.app.service;

public class UserService {

    private static UserService sInstance = new UserService();


    public static UserService getInstance() {
        return sInstance;
    }
}
