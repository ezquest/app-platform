package yonsei.app.hw1.action.message;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.vertx.core.json.JsonObject;

public final class ResponseMessage {
    public enum SingInMessage {
        SUCCESS(true, "Account successfully created."),
        EXIST(false, "Account already exists");

        private boolean result;
        private String message;

        SingInMessage(boolean result, String message) {
            this.result = result;
            this.message = message;
        }

        public boolean getResult() {
            return result;
        }

        public String getMessage() {
            return message;
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class SignInResponse {

        public boolean result;
        public String message;

        public SignInResponse(SingInMessage singInMessage) {
            this.result = singInMessage.getResult();
            this.message = singInMessage.getMessage();
        }

        public JsonObject parseJsonObject() {
            return JsonObject.mapFrom(this);
        }
    }

    public enum SignUpMessage {
        SUCCESS(true, "You have successfully signed up."),
        FAILED(false, "ID or Password incorrect");

        private boolean result;
        private String message;

        SignUpMessage(boolean result, String message) {
            this.result = result;
            this.message = message;
        }

        public boolean getResult() {
            return result;
        }

        public String getMessage() {
            return message;
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class SignUpResponse {
        public boolean result;
        public String message;

        @JsonProperty("session_id")
        public String sessionId;

        public SignUpResponse(SignUpMessage signUpMessage, String sessionId) {
            this.result = signUpMessage.getResult();
            this.message = signUpMessage.getMessage();
            this.sessionId = sessionId;
        }

        public JsonObject parseJsonObject() {
            return JsonObject.mapFrom(this);
        }
    }
}
