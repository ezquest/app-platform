package yonsei.app.hw1.action.command;

import io.vertx.core.json.JsonObject;
import yonsei.app.hw1.RedisDb;
import yonsei.app.hw1.action.message.ResponseMessage;

public class SignInCommand extends RedisDb implements Command {

    private String id;
    private String password;

    @Override
    public JsonObject execute(JsonObject jsonObject) {
        if (jsonObject.containsKey("id") && jsonObject.containsKey("password")) {
            id = jsonObject.getString("id", "");
            password = jsonObject.getString("password", "");

            return executeQuery(jedis -> {
                boolean isIdExist = jedis.exists("authorTable:uidx:" + id);
                if (isIdExist) {
                    return new ResponseMessage.SignInResponse(ResponseMessage.SingInMessage.EXIST).parseJsonObject();
                }
                jedis.set("authorTable:uidx:" + id, getNextUserIndex().toString());
                jedis.set("authorTable:pwd:" + id, password);
                return new ResponseMessage.SignInResponse(ResponseMessage.SingInMessage.SUCCESS).parseJsonObject();
            });
        }
        return null;
    }
}
