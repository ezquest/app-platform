package yonsei.app.hw1.service;


import io.vertx.core.json.JsonObject;
import yonsei.app.hw1.action.command.SignInCommand;
import yonsei.app.hw1.action.command.SignUpCommand;

public class MessageService {
    private static MessageService sInstance = new MessageService();

    public static MessageService getInstance() {
        return sInstance;
    }

    public JsonObject execute(String method, JsonObject jsonObject) {
        switch (method) {
            case "sign_in":
                return new SignInCommand().execute(jsonObject);
            case "sign_up":
                return new SignUpCommand().execute(jsonObject);
            default:
                return null;
        }
    }
}
