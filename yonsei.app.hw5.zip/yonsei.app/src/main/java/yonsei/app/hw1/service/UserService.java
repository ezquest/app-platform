package yonsei.app.hw1.service;

public class UserService {

    private static UserService sInstance = new UserService();


    public static UserService getInstance() {
        return sInstance;
    }
}
