package yonsei.app.hw1.action.command;

import io.vertx.core.json.JsonObject;
import yonsei.app.hw1.RedisDb;
import yonsei.app.hw1.action.message.ResponseMessage;

import java.util.UUID;

public class SignUpCommand extends RedisDb implements Command {
    private String id;
    private String password;

    @Override
    public JsonObject execute(JsonObject jsonObject) {
        if (jsonObject.containsKey("id") && jsonObject.containsKey("password")) {
            id = jsonObject.getString("id", "");
            password = jsonObject.getString("password", "");

            System.out.println(id);
            System.out.println(password);

            return executeQuery(jedis -> {
                boolean isIdExist = jedis.exists("authorTable:uidx:" + id);
                System.out.println(isIdExist);
                if (isIdExist) {
                    String userPassword = jedis.get("authorTable:pwd:" + id);
                    if (userPassword.equals(password)) {
                        String sessionId = UUID.randomUUID().toString();
                        jedis.set("authorTable:session:" + id, sessionId);
                        return new ResponseMessage.SignUpResponse(ResponseMessage.SignUpMessage.SUCCESS, sessionId).parseJsonObject();
                    }
                }
                return new ResponseMessage.SignUpResponse(ResponseMessage.SignUpMessage.FAILED, null).parseJsonObject();
            });
        }
        return new ResponseMessage.SignUpResponse(ResponseMessage.SignUpMessage.FAILED, null).parseJsonObject();
    }
}
