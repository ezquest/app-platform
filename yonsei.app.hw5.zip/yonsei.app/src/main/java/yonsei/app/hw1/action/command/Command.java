package yonsei.app.hw1.action.command;

import io.vertx.core.json.JsonObject;

public interface Command {
    JsonObject execute(JsonObject jsonObject);
}
