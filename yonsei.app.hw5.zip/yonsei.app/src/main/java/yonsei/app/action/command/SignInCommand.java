package yonsei.app.action.command;

import io.vertx.core.json.JsonObject;
import yonsei.app.RedisDb;

import java.util.UUID;

import static yonsei.app.action.message.ResponseMessage.*;

public class SignInCommand extends RedisDb implements Command {
    public static final String commandName = "sign_up";
    private String id;
    private String password;

    @Override
    public JsonObject execute(JsonObject jsonObject) {
        if (jsonObject.containsKey("id") && jsonObject.containsKey("password")) {
            id = jsonObject.getString("id", "");
            password = jsonObject.getString("password", "");

            System.out.println(id);
            System.out.println(password);

            return executeQuery(jedis -> {
                boolean isIdExist = jedis.exists("authorTable:uidx:" + id);
                System.out.println(isIdExist);
                if (isIdExist) {
                    String userPassword = jedis.get("authorTable:pwd:" + id);
                    if (userPassword.equals(password)) {
                        String sessionId = UUID.randomUUID().toString();
//                        jedis.set("authorTable:session:" + id, sessionId);
                        jedis.setex("authorTable:session:" + id, 60, sessionId);
                        return new SignInResponse(SignInMessage.SUCCESS, sessionId).parseJsonObject();
                    }
                }
                return new SignInResponse(SignInMessage.FAILED, null).parseJsonObject();
            });
        }
        return new SignInResponse(SignInMessage.FAILED, null).parseJsonObject();
    }
}
