package yonsei.app.action.command;

import io.vertx.core.json.JsonObject;
import yonsei.app.RedisDb;

import static yonsei.app.action.message.ResponseMessage.*;

public class SignUpCommand extends RedisDb implements Command {
    public static final String commandName = "sign_in";

    private String id;
    private String password;

    @Override
    public JsonObject execute(JsonObject jsonObject) {
        if (jsonObject.containsKey("id") && jsonObject.containsKey("password")) {
            id = jsonObject.getString("id", "");
            password = jsonObject.getString("password", "");

            return executeQuery(jedis -> {
                boolean isIdExist = jedis.exists("authorTable:uidx:" + id);
                if (isIdExist) {
                    return new SignUpResponse(SingUpMessage.EXIST).parseJsonObject();
                }
                jedis.set("authorTable:uidx:" + id, getNextUserIndex().toString());
                jedis.set("authorTable:pwd:" + id, password);
                return new SignUpResponse(SingUpMessage.SUCCESS).parseJsonObject();
            });
        }
        return JsonObject.mapFrom(SingUpMessage.ERROR);
    }
}
