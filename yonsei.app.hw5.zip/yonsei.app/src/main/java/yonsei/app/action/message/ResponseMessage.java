package yonsei.app.action.message;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.vertx.core.json.JsonObject;

public final class ResponseMessage {
    @JsonFormat(shape = JsonFormat.Shape.OBJECT)
    public enum SingUpMessage {
        SUCCESS(200, "Account successfully created."),
        EXIST(409, "Account already exists."),
        ERROR(400, "Invalid User ID and Password.");

        @JsonProperty("status_code")
        private int statusCode;
        private String message;

        SingUpMessage(int statusCode, String message) {
            this.statusCode = statusCode;
            this.message = message;
        }

        public int getStatusCode() {
            return statusCode;
        }

        public String getMessage() {
            return message;
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class SignUpResponse {
        @JsonProperty("status_code")
        public int statusCode;
        public String message;

        public SignUpResponse(SingUpMessage signUpMessage) {
            this.statusCode = signUpMessage.getStatusCode();
            this.message = signUpMessage.getMessage();
        }

        public JsonObject parseJsonObject() {
            return JsonObject.mapFrom(this);
        }
    }

    public enum SignInMessage {
        SUCCESS(200, "You have successfully signed up."),
        FAILED(401, "Incorrect User ID or Password.");

        private int statusCode;
        private String message;

        SignInMessage(int statusCode, String message) {
            this.statusCode = statusCode;
            this.message = message;
        }

        public int getStatusCode() {
            return statusCode;
        }

        public String getMessage() {
            return message;
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class SignInResponse {
        @JsonProperty("status_code")
        public int statusCode;
        public String message;

        @JsonProperty("session_id")
        public String sessionId;

        public SignInResponse(SignInMessage signInMessage, String sessionId) {
            this.statusCode = signInMessage.getStatusCode();
            this.message = signInMessage.getMessage();
            this.sessionId = sessionId;
        }

        public JsonObject parseJsonObject() {
            return JsonObject.mapFrom(this);
        }
    }

    @JsonFormat(shape = JsonFormat.Shape.OBJECT)
    public enum CommonErrorMessage {
        BAD_REQUEST(400, "Bad Request");

        @JsonProperty("status_code")
        private int statusCode;
        private String message;

        CommonErrorMessage(int statusCode, String message) {
            this.statusCode = statusCode;
            this.message = message;
        }

        public int getStatusCode() {
            return statusCode;
        }

        public String getMessage() {
            return message;
        }
    }
}
