package yonsei.app.action.command;

import io.vertx.core.json.JsonObject;

public interface Command {
    JsonObject execute(JsonObject jsonObject);
}
