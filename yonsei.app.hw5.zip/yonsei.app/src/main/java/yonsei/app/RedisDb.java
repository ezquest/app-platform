package yonsei.app;

import io.vertx.core.json.JsonObject;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class RedisDb {

    private JedisPool pool(String host, int port, String password) {
        return new JedisPool(new JedisPoolConfig(), host, port, 10000, password);
    }

    protected JsonObject executeQuery(Action action) {
        JedisPool pool = pool("127.0.0.1", 7468, "asdf1234");
        JsonObject result;
        try (Jedis jedis = pool.getResource()) {
            result = action.action(jedis);
        }
        pool.close();
        return result;
    }

    protected Long getNextUserIndex() {
        JedisPool pool = pool("127.0.0.1", 7468, "asdf1234");
        long nextUserIndex;
        try (Jedis jedis = pool.getResource()) {
            if (jedis.exists("nextUserIndex")) {
                nextUserIndex = jedis.incr("nextUserIndex");
            } else {
                jedis.set("nextUserIndex", "0");
                nextUserIndex = 0;
            }
        }
        pool.close();
        return nextUserIndex;
    }

    protected interface Action {
        JsonObject action(Jedis jedis);
    }
}
