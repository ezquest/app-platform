package yonsei.app;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Vertx;
import io.vertx.core.http.HttpServer;
import io.vertx.core.http.HttpServerResponse;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;
import yonsei.app.service.MessageService;

public class MainServerVerticle extends AbstractVerticle {

    public static void main(String[] args) {
        Vertx vertx = Vertx.vertx();
        vertx.deployVerticle(new MainServerVerticle());
    }

    @Override
    public void start() {
        Router route = Router.router(vertx);

        route.route().handler(BodyHandler.create());
        route.post("/api").handler(this::handleCommand);

        HttpServer server = vertx.createHttpServer();

        server.requestHandler(route);
        server.listen(8080, handler -> {
            if (handler.succeeded()) {
                System.out.println("Server is now running");
            } else {
                System.err.println("Failed to start Server");
            }
        });
    }

    private void handleCommand(RoutingContext routingContext) {
        JsonObject jsonBody = routingContext.getBodyAsJson();


        JsonObject retJsonObject = MessageService.getInstance().execute(jsonBody);

        HttpServerResponse response = routingContext.response();
        response.putHeader("content-type", "application/json");
        response.setStatusCode(retJsonObject.getInteger("status_code"));
        response.end(retJsonObject.toString());
    }
}
