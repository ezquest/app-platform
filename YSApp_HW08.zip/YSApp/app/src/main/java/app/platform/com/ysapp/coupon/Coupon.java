package app.platform.com.ysapp.coupon;

public interface Coupon {
    enum Type {
        HEADER,
        CONTENT
    }
    Type getType();
}
