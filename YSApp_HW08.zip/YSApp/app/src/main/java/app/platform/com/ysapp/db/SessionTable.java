package app.platform.com.ysapp.db;

import android.content.Context;

public class SessionTable {
    private static final String KEY = "session_id";

    private static class LazyHolder {
        static final SessionTable INSTANCE = new SessionTable();
    }

    public static SessionTable getInstance() {
        return LazyHolder.INSTANCE;
    }

    public String getSession(Context context) {
        return SharedPreferencesHelper.getString(context, KEY);
    }

    public void putSession(Context context, String session) {
        SharedPreferencesHelper.putString(context, KEY, session);
    }

    public void removeSession(Context context) {
        SharedPreferencesHelper.remove(context, KEY);
    }

    public boolean hasSession(Context context) {
        return SharedPreferencesHelper.hasKey(context, KEY);
    }
}
