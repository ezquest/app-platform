package app.platform.com.ysapp.coupon;

import java.util.ArrayList;
import java.util.List;

import app.platform.com.ysapp.R;

public class HeaderCoupon implements Coupon {
    public String titleOne;
    public String infoOne;
    public String titleTwo;
    public String infoTwo;
    public int headerImageUrl;

    public HeaderCoupon(String titleOne, String infoOne, String titleTwo, String infoTwo,
                        int headerImageUrl) {
        this.titleOne = titleOne;
        this.infoOne = infoOne;
        this.titleTwo = titleTwo;
        this.infoTwo = infoTwo;
        this.headerImageUrl = headerImageUrl;
    }

    @Override
    public Type getType() {
        return Type.HEADER;
    }

    public static HeaderCoupon getTestData() {
        HeaderCoupon headerCoupon = new HeaderCoupon("STEPS TO USE", "3944(2.43KM)",
                "24H TOTAL", "3944", R.drawable.cover);
        return headerCoupon;
    }
}
