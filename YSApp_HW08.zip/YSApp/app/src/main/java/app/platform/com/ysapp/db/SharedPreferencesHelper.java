package app.platform.com.ysapp.db;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferencesHelper {

//    public static void putSessionId(Context context, String sessionId) {
//        SharedPreferences pref = context.getSharedPreferences("pref", Context.MODE_PRIVATE);
//        SharedPreferences.Editor editor = pref.edit();
//        editor.putString("session_id", sessionId);
//        editor.apply();
//    }
//
//    public static void removeSessionId(Context context) {
//        SharedPreferences pref = context.getSharedPreferences("pref", Context.MODE_PRIVATE);
//        SharedPreferences.Editor editor = pref.edit();
//        editor.remove("session_id");
//        editor.apply();
//    }
//
//    public static String getSessionId(Context context) {
//        SharedPreferences pref = context.getSharedPreferences("pref", Context.MODE_PRIVATE);
//        String sessionId = pref.getString("session_id", "");
//        return sessionId;
//    }

    public static void putString(Context context, String key, String value) {
        SharedPreferences pref = context.getSharedPreferences("pref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public static void remove(Context context, String key) {
        SharedPreferences pref = context.getSharedPreferences("pref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.remove(key);
        editor.apply();
    }

    public static String getString(Context context, String key) {
        SharedPreferences pref = context.getSharedPreferences("pref", Context.MODE_PRIVATE);
        String sessionId = pref.getString(key, "");
        return sessionId;
    }

    public static boolean hasKey(Context context, String key) {
        SharedPreferences pref = context.getSharedPreferences("pref", Context.MODE_PRIVATE);
        return pref.contains(key);
    }
}
