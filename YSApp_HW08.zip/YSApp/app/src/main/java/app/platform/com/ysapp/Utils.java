package app.platform.com.ysapp;

import android.content.Context;
import android.content.res.Resources;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Utils {

    public static String getRawJsonString(Context context, int resource) {
        StringBuilder jsonString = new StringBuilder();
        Resources res = context.getResources();
        try (InputStream in = res.openRawResource(resource)) {
            try (InputStreamReader stream = new InputStreamReader(in, "utf-8");
                 BufferedReader buffer = new BufferedReader(stream)) {
                String read;
                while ((read = buffer.readLine()) != null) {
                    jsonString.append(read);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonString.toString();
    }

    public static String Sha512(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            byte[] messageDigest = md.digest(input.getBytes());
            BigInteger no = new BigInteger(1, messageDigest);
            String hashText = no.toString(16);
            while (hashText.length() < 32) {
                hashText = "0" + hashText;
            }
            return hashText;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }
}
