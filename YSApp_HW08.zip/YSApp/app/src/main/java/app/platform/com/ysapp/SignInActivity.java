package app.platform.com.ysapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;

import app.platform.com.ysapp.db.SessionTable;
import app.platform.com.ysapp.server.RequestHelper;
import app.platform.com.ysapp.server.ServerRequestManager;
import butterknife.BindView;
import butterknife.ButterKnife;

public class SignInActivity extends AppCompatActivity {
    private static final String TAG = "YS-SignInActivity";
    private static final int REQUEST_SIGN_UP = 200;

    @BindView(R.id.sign_in_email_edit_text)
    EditText _emailText;
    @BindView(R.id.sign_in_password_edit_text)
    EditText _passwordText;
    @BindView(R.id.sign_in_sign_in_button)
    Button _signInButton;
    @BindView(R.id.sign_in_link_sign_up_text_view)
    TextView _signUpLink;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        ButterKnife.bind(this);

        _signInButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                signIn();
            }
        });

        _signUpLink.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // Start the Signup activity
                Intent intent = new Intent(getApplicationContext(), SignUpActivity.class);
                startActivityForResult(intent, REQUEST_SIGN_UP);
//                finish();
//                overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
            }
        });
    }

    public void signIn() {
        if (!validate()) {
            onSignInFailed();
            return;
        }

        _signInButton.setEnabled(false);

        final ProgressDialog progressDialog = new ProgressDialog(SignInActivity.this);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Authenticating...");
        progressDialog.show();

        String email = _emailText.getText().toString();
        String password = _passwordText.getText().toString();

        JsonObject content = RequestHelper.makeSignInRequest(email, password);
        ServerRequestManager.getInstance().requestWithJson(content, new ServerRequestManager.ServerCallback() {
            @Override
            public void onResult(JsonObject result) {
                Log.d(TAG, result.toString());
                String sessionId = result.get("session_id").getAsString();
                SessionTable.getInstance().putSession(SignInActivity.this, sessionId);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        onSignInSuccess();
                        // onLoginFailed();
                        progressDialog.dismiss();
                    }
                });
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        if (requestCode == REQUEST_SIGN_UP) {
//            if (resultCode == RESULT_OK) {
//                // TODO: Implement successful signup logic here
//                this.finish();
//            }
//        }
    }

    @Override
    public void onBackPressed() {
        // Disable going back to the MainActivity
        moveTaskToBack(true);
    }

    public void onSignInSuccess() {
        _signInButton.setEnabled(true);
        Intent data = new Intent();
        Log.d(TAG, _emailText.getText().toString());
        data.putExtra("id", _emailText.getText().toString());
        setResult(RESULT_OK, data);
        finish();
    }

    public void onSignInFailed() {
        Toast.makeText(getBaseContext(), "SignIn failed", Toast.LENGTH_LONG).show();
        _signInButton.setEnabled(true);
    }

    public boolean validate() {
        boolean valid = true;

        String email = _emailText.getText().toString();
        String password = _passwordText.getText().toString();

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _emailText.setError("enter a valid email address");
            valid = false;
        } else {
            _emailText.setError(null);
        }

        if (password.isEmpty() || password.length() < 4 || password.length() > 10) {
            _passwordText.setError("between 4 and 10 alphanumeric characters");
            valid = false;
        } else {
            _passwordText.setError(null);
        }
        return valid;
    }
}
