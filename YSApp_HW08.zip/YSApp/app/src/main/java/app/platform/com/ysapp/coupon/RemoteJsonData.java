package app.platform.com.ysapp.coupon;

import com.google.gson.annotations.SerializedName;

public final class RemoteJsonData {

    public static class CouponJsonType {
        @SerializedName("main_title")
        public String mainTitle = "";
        @SerializedName("main_info")
        public String mainInfo = "";
        @SerializedName("main_detail")
        public String mainDetail = "";
        @SerializedName("main_image_url")
        public String mainImageUrl = "";
        @SerializedName("sub_title_one")
        public String subTitleOne = "";
        @SerializedName("sub_info_one")
        public String subInfoOne = "";
        @SerializedName("sub_title_two")
        public String subTitleTwo = "";
        @SerializedName("sub_info_two")
        public String subInfoTwo = "";
        @SerializedName("sub_title_three")
        public String subTitleThree = "";
        @SerializedName("sub_info_three")
        public String subInfoThree = "";
    }
}
