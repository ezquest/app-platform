package app.platform.com.ysapp.server;


import com.google.gson.JsonObject;

public class RequestHelper {

    public static JsonObject makeSignInRequest(String id, String pwd) {
        JsonObject value = new JsonObject();
        value.addProperty("command", "Auth:SignIn");
        value.addProperty("id", id);
        value.addProperty("pwd", pwd);
        return value;
    }

    public static JsonObject makeSignUpRequest(String id, String pwd) {
        JsonObject value = new JsonObject();
        value.addProperty("command", "Auth:SignUp");
        value.addProperty("id", id);
        value.addProperty("pwd", pwd);
        return value;
    }
}
